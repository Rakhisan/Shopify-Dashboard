(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_catalogue_product-search_ProductSearch_module_11d33f43.css",
  "static/chunks/node_modules_react-icons_ai_index_mjs_b8cfc3ce._.js",
  "static/chunks/node_modules_f42bb3c5._.js",
  "static/chunks/app_catalogue_product-search_dd788ed6._.js"
],
    source: "dynamic"
});
