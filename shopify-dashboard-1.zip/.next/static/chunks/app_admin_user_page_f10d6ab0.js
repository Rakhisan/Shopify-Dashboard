(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_admin_user_UsersTable_module_402423a1.css",
  "static/chunks/_4f9d250a._.js"
],
    source: "dynamic"
});
