(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/app/catalogue/your-catalog/YourCatalogue.module.css [app-client] (css module)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v({
  "actionColumn": "YourCatalogue-module__0ieiVW__actionColumn",
  "actionMenu": "YourCatalogue-module__0ieiVW__actionMenu",
  "actionMenuItem": "YourCatalogue-module__0ieiVW__actionMenuItem",
  "actions": "YourCatalogue-module__0ieiVW__actions",
  "arrowIcon": "YourCatalogue-module__0ieiVW__arrowIcon",
  "button": "YourCatalogue-module__0ieiVW__button",
  "catalogSelect": "YourCatalogue-module__0ieiVW__catalogSelect",
  "catalogueNameHeader": "YourCatalogue-module__0ieiVW__catalogueNameHeader",
  "container": "YourCatalogue-module__0ieiVW__container",
  "customDropdown": "YourCatalogue-module__0ieiVW__customDropdown",
  "deleteAction": "YourCatalogue-module__0ieiVW__deleteAction",
  "dropdownButton": "YourCatalogue-module__0ieiVW__dropdownButton",
  "dropdownIcon": "YourCatalogue-module__0ieiVW__dropdownIcon",
  "dropdownItem": "YourCatalogue-module__0ieiVW__dropdownItem",
  "dropdownMenu": "YourCatalogue-module__0ieiVW__dropdownMenu",
  "headerRow": "YourCatalogue-module__0ieiVW__headerRow",
  "inStock": "YourCatalogue-module__0ieiVW__inStock",
  "input": "YourCatalogue-module__0ieiVW__input",
  "lowStock": "YourCatalogue-module__0ieiVW__lowStock",
  "menuButton": "YourCatalogue-module__0ieiVW__menuButton",
  "nameCell": "YourCatalogue-module__0ieiVW__nameCell",
  "nameId": "YourCatalogue-module__0ieiVW__nameId",
  "nameText": "YourCatalogue-module__0ieiVW__nameText",
  "outStock": "YourCatalogue-module__0ieiVW__outStock",
  "pageSize": "YourCatalogue-module__0ieiVW__pageSize",
  "pagination": "YourCatalogue-module__0ieiVW__pagination",
  "paginationButton": "YourCatalogue-module__0ieiVW__paginationButton",
  "paginationButtons": "YourCatalogue-module__0ieiVW__paginationButtons",
  "paginationInfo": "YourCatalogue-module__0ieiVW__paginationInfo",
  "paginationInfos": "YourCatalogue-module__0ieiVW__paginationInfos",
  "plusIcon": "YourCatalogue-module__0ieiVW__plusIcon",
  "rotated": "YourCatalogue-module__0ieiVW__rotated",
  "searchIcon": "YourCatalogue-module__0ieiVW__searchIcon",
  "searchWrapper": "YourCatalogue-module__0ieiVW__searchWrapper",
  "select": "YourCatalogue-module__0ieiVW__select",
  "selected": "YourCatalogue-module__0ieiVW__selected",
  "showText": "YourCatalogue-module__0ieiVW__showText",
  "showWrapper": "YourCatalogue-module__0ieiVW__showWrapper",
  "statusBadge": "YourCatalogue-module__0ieiVW__statusBadge",
  "table": "YourCatalogue-module__0ieiVW__table",
  "tableContainer": "YourCatalogue-module__0ieiVW__tableContainer",
  "tableHeaderRow": "YourCatalogue-module__0ieiVW__tableHeaderRow",
  "title": "YourCatalogue-module__0ieiVW__title",
  "verticalDots": "YourCatalogue-module__0ieiVW__verticalDots",
});
}}),
"[project]/app/images/Handmade Pouch.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/Handmade Pouch.bf09b535.png");}}),
"[project]/app/images/Handmade Pouch.png.mjs { IMAGE => \"[project]/app/images/Handmade Pouch.png (static in ecmascript)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Handmade__Pouch$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/Handmade Pouch.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Handmade__Pouch$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 435,
    height: 580,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAYAAADaxo44AAAAt0lEQVR42m3OvQqCUBgG4BMFIY5dRVN3EEQ01db1tLU3lRRERHvR0o+QiyWGYEFJ2pIUQUo/VIPH4/mpHJwavm94n+F9AWMM/LvwUUriD+eQfbp2jpCAi8CHXnI56TS0kaB571s6grt7yuhic2tILed1tcshUEpjli5V1tM6NWYCO5ty+5slAPIhr4y7Q7FXhYt+DZrqYI4RTP2A22/U/EoRSztdLl6OVgFjxIcdhBAQBAhgjKO5H98uje/s00cDAAAAAElFTkSuQmCC",
    blurWidth: 6,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/images/Watch.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/Watch.d27c2287.png");}}),
"[project]/app/images/Watch.png.mjs { IMAGE => \"[project]/app/images/Watch.png (static in ecmascript)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Watch$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/Watch.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Watch$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 464,
    height: 580,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAYAAADaxo44AAAAwElEQVR42j2OPQuCUBiFbxAREdTc1BoRjRFk0DdFoHM11V8IChpaItwbxUUCabfZdukLCn9AjhqIIem9V9MLNrwvHJ5zDgf4vg/CQwjFMcbxSJNn23aa43hWEPZrx3GTBHieB06y3K+Vi2avThmPp9omIKgAB1GcTTsVPB/RSFHOEwIghECSjuNqqQCZJvW93u4MAa7rgpem5RutrjoY0hdd13P/hGmaqcVyxW+27C4wJggIJoapmGG8s5b1yURzf+vbfufC+eu6AAAAAElFTkSuQmCC",
    blurWidth: 6,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/images/Headphone.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/Headphone.cc22d041.png");}}),
"[project]/app/images/Headphone.png.mjs { IMAGE => \"[project]/app/images/Headphone.png (static in ecmascript)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Headphone$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/Headphone.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Headphone$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 384,
    height: 581,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAYAAAAx8TU7AAAAnUlEQVR42l1NvQqCUBj9IkGopaEuuPQQQlM9Sg/RFrT2MoVRYTQW7VlGS2USRaTXLLt5Uxr9dBB0OJwfOOdAEP4hj1TwX1hELiQhGuFwNBqL5aqtbfSmzwMBLNupngxT/jC/pO/2sk2fBM7mpT4YKt3r7S6ps3mHOq4Eb4+VJ1O1t9a2LWU07mNdTE7cl1d5WJRgtZZ5x23CvlyMdQTz4m+b6RQH7QAAAABJRU5ErkJggg==",
    blurWidth: 5,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/images/iphone.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/iphone.163c0acc.png");}}),
"[project]/app/images/iphone.png.mjs { IMAGE => \"[project]/app/images/iphone.png (static in ecmascript)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$iphone$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/iphone.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$iphone$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 464,
    height: 580,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAYAAADaxo44AAAA00lEQVR42gHIADf/AOrr7QDp6+wA6OnrAPDw8gD29vcA8/PzAADo6+wA6evsAOPk5QDn5ecO8vLzBezs7QAA5+rrAOfo6QDNyMgYr4SDqcO4uHbe3+EOAOXo6QDk5ucFqJCUgK9ZWfuadHbiycnMMwDj5ecAvLi6QXtTVefHZGH9tpCQit7e4AcA3N/hB5yFj6CsVGz+wHJv9tjQ0Ufe3+EAAN3h4wG4ub00nHyOrL2rsYHh4uQe3eDhAADZ3eAA2t7gANDR1A3c3+EE4OLkANze4QC8Fnzsy0yHLgAAAABJRU5ErkJggg==",
    blurWidth: 6,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/images/Puma Shoes.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/Puma Shoes.d9723d92.png");}}),
"[project]/app/images/Puma Shoes.png.mjs { IMAGE => \"[project]/app/images/Puma Shoes.png (static in ecmascript)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Puma__Shoes$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/Puma Shoes.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Puma__Shoes$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 1170,
    height: 780,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAbElEQVR42kWJvQ5AMBhFPSWrkc07sDEQi4HFwiAWm8EbdPAO/ZlqqsHXtNVIcZJ7c2+OZx4oZZwfSinz4tnY33Z9FCfDOF0AvxDizIu6rBo/CKd5AZBOAABCO8Z0Xbc0KwhhTnxoraWUtu2+AbZRaeapDiVIAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 5
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/images/Imac.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/Imac.a955c732.png");}}),
"[project]/app/images/Imac.png.mjs { IMAGE => \"[project]/app/images/Imac.png (static in ecmascript)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Imac$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/Imac.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Imac$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 1170,
    height: 780,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAiElEQVR42gF9AIL/APr6+vz8/Pr6+vf39/b29vf39/z8/P7+/gD8/Pzz9PS2wMizv8qyt7+2tbjq6ur7+/sA/Pz87e3tmZeal4uBmndVj3FV3tzZ+Pj4APb29u7u7bCkm6mRdqqPaaeZgeLh4PT09ADv7+/t7e3n5+fT09PHx8fZ2dnk5OTq6uoyRWREIciqqQAAAABJRU5ErkJggg==",
    blurWidth: 8,
    blurHeight: 5
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/images/Lego Car.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/Lego Car.a4732ecf.png");}}),
"[project]/app/images/Lego Car.png.mjs { IMAGE => \"[project]/app/images/Lego Car.png (static in ecmascript)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Lego__Car$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/Lego Car.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Lego__Car$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 1331,
    height: 749,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAiElEQVR42gF9AIL/AO3u8O3t7+7u7vLx8fDv8PLz9fX1+PL09wDs7e/s7vDw8PLq3dvNj4PdsKb29fT19PMA7O7w7e7w7tfT0XRfrUYu1J6M+PTw+PXxAOvu8uzu8cSblrZAJsJ9Ze/h1/jz7vn18QDq7fLs7vLW1tm4pqTl18718Ov38+/49fBfiWXuhbJOtwAAAABJRU5ErkJggg==",
    blurWidth: 8,
    blurHeight: 5
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/images/SkinCare.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/SkinCare.1336f420.png");}}),
"[project]/app/images/SkinCare.png.mjs { IMAGE => \"[project]/app/images/SkinCare.png (static in ecmascript)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$SkinCare$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/SkinCare.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$SkinCare$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 1053,
    height: 811,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAfUlEQVR42j2MywqDMBRE/Xzpv0SsLUgXQheCpQsVHytFYl43xgg+cK+SIAwMcw6MowS/AqIqim8USUYNcUyNUiqlked/whAoseKkjNBlXtZt958vDyGGsRVq1E3TTnrqOuy6jySO7ysAkL/kn6fZOwgE6a04M3BelyUnvZkHUF57uBcrab8AAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 6
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/images/Nike Shoes.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/Nike Shoes.72b02811.png");}}),
"[project]/app/images/Nike Shoes.png.mjs { IMAGE => \"[project]/app/images/Nike Shoes.png (static in ecmascript)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Nike__Shoes$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/Nike Shoes.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Nike__Shoes$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 387,
    height: 581,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAi0lEQVR42gGAAH//AO3t7PLy8vX19fX19fT08wDm5ebg4OH29vb39/f39/YAn5eaZmZp5d3e8Nzc9vX1AM/Awm9YWtNxb49dXcK8vQDqwMDVV1XMQT57RULZop4A7dXV9GFb7G1p6nJn9rCnAO7e3emJgOS1svTj4ff29gDp6Ojs5eTz8fH29fX29vaaMVz5Gnq/nQAAAABJRU5ErkJggg==",
    blurWidth: 5,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/catalogue/your-catalog/YourCatalogue.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Catalog)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/app/catalogue/your-catalog/YourCatalogue.module.css [app-client] (css module)");
// import Handmadepouch from './images/Handmadepouch.png';
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Handmade__Pouch$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$Handmade__Pouch$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/Handmade Pouch.png.mjs { IMAGE => "[project]/app/images/Handmade Pouch.png (static in ecmascript)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Watch$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$Watch$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/Watch.png.mjs { IMAGE => "[project]/app/images/Watch.png (static in ecmascript)" } [app-client] (structured image object, ecmascript)');
//import Smartwatch from "../../images/smartwatch-e1.png";
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Headphone$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$Headphone$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/Headphone.png.mjs { IMAGE => "[project]/app/images/Headphone.png (static in ecmascript)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$iphone$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$iphone$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/iphone.png.mjs { IMAGE => "[project]/app/images/iphone.png (static in ecmascript)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Puma__Shoes$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$Puma__Shoes$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/Puma Shoes.png.mjs { IMAGE => "[project]/app/images/Puma Shoes.png (static in ecmascript)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Imac$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$Imac$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/Imac.png.mjs { IMAGE => "[project]/app/images/Imac.png (static in ecmascript)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Lego__Car$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$Lego__Car$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/Lego Car.png.mjs { IMAGE => "[project]/app/images/Lego Car.png (static in ecmascript)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$SkinCare$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$SkinCare$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/SkinCare.png.mjs { IMAGE => "[project]/app/images/SkinCare.png (static in ecmascript)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Nike__Shoes$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$Nike__Shoes$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/Nike Shoes.png.mjs { IMAGE => "[project]/app/images/Nike Shoes.png (static in ecmascript)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ai$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/ai/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const catalogData = [
    {
        id: "#302012",
        name: "Handmade Pouch",
        vendor: "Acme Corp",
        category: "Electronics",
        stock: "50 units",
        status: "In-Stock",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Handmade__Pouch$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$Handmade__Pouch$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: "#302011",
        name: "Smartwatch E2",
        vendor: "Tech Innovations",
        category: "Home Appliances",
        stock: "75 units",
        status: "Low Stock",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Watch$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$Watch$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: "#302002",
        name: "Smartwatch E1",
        vendor: "Global Solutions",
        category: "Furniture",
        stock: "100 units",
        status: "Out-of-Stock",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Watch$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$Watch$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: "#301901",
        name: "Headphone G1 Pro",
        vendor: "Eco Enterprises",
        category: "Toys",
        stock: "Weekly",
        status: "Out-of-Stock",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Headphone$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$Headphone$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: "#301900",
        name: "Iphone X",
        vendor: "Smart Devices Inc.",
        category: "Books",
        stock: "150 units",
        status: "Low Stock",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$iphone$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$iphone$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: "#301800",
        name: "Puma Shoes",
        vendor: "NextGen Technologies",
        category: "Clothing",
        stock: "200 units",
        status: "Low Stock",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Puma__Shoes$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$Puma__Shoes$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: "#301701",
        name: "Imac 2021",
        vendor: "Cloud Services Ltd.",
        category: "Sports Equipment",
        stock: "250 units",
        status: "In-Stock",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Imac$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$Imac$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: "#301600",
        name: "Nike Shoes",
        vendor: "Digital Ventures",
        category: "Beauty Products",
        stock: "300 units",
        status: "Out-of-Stock",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Nike__Shoes$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$Nike__Shoes$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: "#301500",
        name: "Lego Car",
        vendor: "Future Dynamics",
        category: "Automotive Accessories",
        stock: "350 units",
        status: "Out-of-Stock",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$Lego__Car$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$Lego__Car$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: "#301400",
        name: "Skincare Alia 1",
        vendor: "Innovatech Solutions",
        category: "Gardening Tools",
        stock: "400 units",
        status: "In-Stock",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$SkinCare$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$SkinCare$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    }
];
const statusColor = {
    "In-Stock": __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].inStock,
    "Low Stock": __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].lowStock,
    "Out-of-Stock": __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].outStock
};
function Catalog() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [showActionMenu, setShowActionMenu] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [showPageSizeDropdown, setShowPageSizeDropdown] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selectedPageSize, setSelectedPageSize] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(10);
    const pageSizeOptions = [
        10,
        20,
        50
    ];
    const handleAddUser = ()=>{
        router.push("/catalogue/your-catalog/add-catalog");
    };
    const handleEditCatalog = ()=>{
        router.push("/catalogue/your-catalog/edit-catalog");
    };
    const toggleActionMenu = (index)=>{
        setShowActionMenu(showActionMenu === index ? null : index);
    };
    const togglePageSizeDropdown = ()=>{
        setShowPageSizeDropdown(!showPageSizeDropdown);
    };
    const handlePageSizeSelect = (size)=>{
        setSelectedPageSize(size);
        setShowPageSizeDropdown(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headerRow,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                        children: "Your Catalogue"
                    }, void 0, false, {
                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                        lineNumber: 153,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actions,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchWrapper,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchIcon,
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        stroke: "currentColor",
                                        strokeWidth: 2,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            d: "M21 21l-4.35-4.35m0 0A7.5 7.5 0 1110.5 3a7.5 7.5 0 016.15 13.65z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 164,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 156,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        placeholder: "Search Catalog",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].input
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 170,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                lineNumber: 155,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].button,
                                onClick: handleAddUser,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].plusIcon,
                                        children: "+"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 178,
                                        columnNumber: 13
                                    }, this),
                                    " Catalogue"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                lineNumber: 177,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                        lineNumber: 154,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                lineNumber: 152,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].tableContainer,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].table,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].tableHeaderRow,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "checkbox"
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                lineNumber: 188,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 187,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "ID"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 190,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].catalogueNameHeader,
                                            children: [
                                                "Catalogue Name",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    width: "18",
                                                    height: "18",
                                                    viewBox: "0 0 18 18",
                                                    fill: "none",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        d: "M4.81 6.75h8.38c.15 0 .3.04.42.13.12.08.22.2.28.34.06.13.08.28.05.42-.03.15-.1.28-.2.39L9.53 12.22c-.14.14-.33.22-.53.22s-.39-.08-.53-.22L4.28 8.03c-.1-.1-.17-.24-.2-.39a.75.75 0 01.47-.88c.12-.09.27-.13.43-.13Z",
                                                        fill: "#8E95A6"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                        lineNumber: 200,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                    lineNumber: 193,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 191,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Vendor"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 206,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Category"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 207,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Stock"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 208,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Status"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 209,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {}, void 0, false, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 210,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                    lineNumber: 186,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                lineNumber: 185,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                children: catalogData.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "checkbox"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                    lineNumber: 217,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                lineNumber: 216,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].nameId,
                                                children: item.id
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                lineNumber: 219,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].nameCell,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        src: item.image,
                                                        alt: item.name,
                                                        width: 30,
                                                        height: 30
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                        lineNumber: 221,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].nameText,
                                                        children: [
                                                            " ",
                                                            item.name
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                        lineNumber: 227,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                lineNumber: 220,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                children: item.vendor
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                lineNumber: 229,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                children: item.category
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                lineNumber: 230,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                children: item.stock
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                lineNumber: 231,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].statusBadge} ${statusColor[item.status]}`,
                                                    children: item.status
                                                }, void 0, false, {
                                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                    lineNumber: 233,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                lineNumber: 232,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actionColumn,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].menuButton,
                                                        onClick: ()=>toggleActionMenu(index),
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            width: "20",
                                                            height: "20",
                                                            viewBox: "0 0 24 24",
                                                            fill: "currentColor",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                                    cx: "12",
                                                                    cy: "12",
                                                                    r: "1"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                                    lineNumber: 253,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                                    cx: "12",
                                                                    cy: "6",
                                                                    r: "1"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                                    lineNumber: 254,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                                    cx: "12",
                                                                    cy: "18",
                                                                    r: "1"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                                    lineNumber: 255,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                            lineNumber: 246,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                        lineNumber: 242,
                                                        columnNumber: 19
                                                    }, this),
                                                    showActionMenu === index && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actionMenu,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actionMenuItem,
                                                                onClick: handleEditCatalog,
                                                                children: "Edit"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                                lineNumber: 260,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actionMenuItem,
                                                                children: "Update"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                                lineNumber: 266,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actionMenuItem} ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].deleteAction}`,
                                                                children: "Delete"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                                lineNumber: 267,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                        lineNumber: 259,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                lineNumber: 241,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, index, true, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 215,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                lineNumber: 213,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                        lineNumber: 184,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].pagination,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].paginationButtons,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].paginationButton,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            width: "24",
                                            height: "24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                                                points: "15 18 9 12 15 6"
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                lineNumber: 292,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 282,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 281,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].paginationButton,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            width: "24",
                                            height: "24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                                                points: "9 18 15 12 9 6"
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                lineNumber: 306,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 296,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 295,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                lineNumber: 280,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].paginationInfo,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Show"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 311,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].customDropdown,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownButton,
                                                onClick: togglePageSizeDropdown,
                                                children: [
                                                    selectedPageSize,
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ai$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AiOutlineCaretDown"], {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownIcon} ${showPageSizeDropdown ? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].rotated : ""}`
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                        lineNumber: 318,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                lineNumber: 313,
                                                columnNumber: 15
                                            }, this),
                                            showPageSizeDropdown && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownMenu,
                                                children: pageSizeOptions.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dropdownItem} ${selectedPageSize === option ? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].selected : ""}`,
                                                        onClick: ()=>handlePageSizeSelect(option),
                                                        children: option
                                                    }, option, false, {
                                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                        lineNumber: 328,
                                                        columnNumber: 21
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                lineNumber: 326,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 312,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                lineNumber: 310,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                        lineNumber: 279,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                lineNumber: 183,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
        lineNumber: 151,
        columnNumber: 5
    }, this);
}
_s(Catalog, "BB2vZxFMT75CS9LN2gBDGC55+qM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = Catalog;
var _c;
__turbopack_context__.k.register(_c, "Catalog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=app_30bf2124._.js.map