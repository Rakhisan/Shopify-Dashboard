(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_admin_user_edituser_EditUser_module_4e3cd96d.css",
  "static/chunks/app_admin_user_edituser_b8ba9917._.js"
],
    source: "dynamic"
});
