(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_admin_user_adduser_AddUser_module_0bdc7ee7.css",
  "static/chunks/app_admin_user_adduser_9317ee24._.js"
],
    source: "dynamic"
});
