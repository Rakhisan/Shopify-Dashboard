(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_catalogue_catalog-filter_CatalogueFilter_module_487be4b6.css",
  "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_18827baf._.js",
  "static/chunks/app_catalogue_catalog-filter_2b3467d3._.js"
],
    source: "dynamic"
});
