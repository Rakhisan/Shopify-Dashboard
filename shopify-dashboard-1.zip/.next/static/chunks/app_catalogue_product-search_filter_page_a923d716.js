(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_catalogue_product-search_filter_Filter_module_f340d07a.css",
  "static/chunks/app_catalogue_product-search_filter_304635cd._.js"
],
    source: "dynamic"
});
