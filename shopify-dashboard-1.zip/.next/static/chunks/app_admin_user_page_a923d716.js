(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_admin_user_UsersTable_module_402423a1.css",
  "static/chunks/node_modules_react-icons_ai_index_mjs_b8cfc3ce._.js",
  "static/chunks/node_modules_next_navigation_ff30cc2f.js",
  "static/chunks/app_admin_user_cb39fecd._.js"
],
    source: "dynamic"
});
