(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_catalogue_product-search_edit-product_EditProduct_module_a4f3d6dd.css",
  "static/chunks/app_catalogue_product-search_edit-product_6666153b._.js"
],
    source: "dynamic"
});
