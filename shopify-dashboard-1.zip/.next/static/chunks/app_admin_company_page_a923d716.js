(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_admin_company_CompanyProfile_module_8cee4f3e.css",
  "static/chunks/app_admin_company_8f7afa69._.js"
],
    source: "dynamic"
});
