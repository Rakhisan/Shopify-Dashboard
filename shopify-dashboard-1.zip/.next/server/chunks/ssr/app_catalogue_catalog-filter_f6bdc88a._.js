module.exports = {

"[project]/app/catalogue/catalog-filter/CatalogueFilter.module.css [app-ssr] (css module)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v({
  "actionsColumn": "CatalogueFilter-module__nkpL0q__actionsColumn",
  "addButton": "CatalogueFilter-module__nkpL0q__addButton",
  "checkboxColumn": "CatalogueFilter-module__nkpL0q__checkboxColumn",
  "container": "CatalogueFilter-module__nkpL0q__container",
  "createdByColumn": "CatalogueFilter-module__nkpL0q__createdByColumn",
  "criteriaColumn": "CatalogueFilter-module__nkpL0q__criteriaColumn",
  "customDropdown": "CatalogueFilter-module__nkpL0q__customDropdown",
  "dropdownButton": "CatalogueFilter-module__nkpL0q__dropdownButton",
  "dropdownIcon": "CatalogueFilter-module__nkpL0q__dropdownIcon",
  "dropdownItem": "CatalogueFilter-module__nkpL0q__dropdownItem",
  "dropdownMenu": "CatalogueFilter-module__nkpL0q__dropdownMenu",
  "filterButton": "CatalogueFilter-module__nkpL0q__filterButton",
  "filterOptions": "CatalogueFilter-module__nkpL0q__filterOptions",
  "filtersTable": "CatalogueFilter-module__nkpL0q__filtersTable",
  "header": "CatalogueFilter-module__nkpL0q__header",
  "idColumn": "CatalogueFilter-module__nkpL0q__idColumn",
  "inputWrapper": "CatalogueFilter-module__nkpL0q__inputWrapper",
  "menuButton": "CatalogueFilter-module__nkpL0q__menuButton",
  "menuDots": "CatalogueFilter-module__nkpL0q__menuDots",
  "menuDropdown": "CatalogueFilter-module__nkpL0q__menuDropdown",
  "nameColumn": "CatalogueFilter-module__nkpL0q__nameColumn",
  "pageSize": "CatalogueFilter-module__nkpL0q__pageSize",
  "pagination": "CatalogueFilter-module__nkpL0q__pagination",
  "paginationButton": "CatalogueFilter-module__nkpL0q__paginationButton",
  "paginationButtons": "CatalogueFilter-module__nkpL0q__paginationButtons",
  "paginationInfo": "CatalogueFilter-module__nkpL0q__paginationInfo",
  "paginationInfos": "CatalogueFilter-module__nkpL0q__paginationInfos",
  "rotated": "CatalogueFilter-module__nkpL0q__rotated",
  "searchContainer": "CatalogueFilter-module__nkpL0q__searchContainer",
  "searchIcon": "CatalogueFilter-module__nkpL0q__searchIcon",
  "searchInput": "CatalogueFilter-module__nkpL0q__searchInput",
  "select": "CatalogueFilter-module__nkpL0q__select",
  "selectContainer": "CatalogueFilter-module__nkpL0q__selectContainer",
  "selected": "CatalogueFilter-module__nkpL0q__selected",
  "selectedRow": "CatalogueFilter-module__nkpL0q__selectedRow",
  "showOptions": "CatalogueFilter-module__nkpL0q__showOptions",
  "showSelect": "CatalogueFilter-module__nkpL0q__showSelect",
  "tableContainer": "CatalogueFilter-module__nkpL0q__tableContainer",
  "title": "CatalogueFilter-module__nkpL0q__title",
});
}}),
"[project]/app/catalogue/catalog-filter/CatalogueFilter.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// components/CatalogueFilter.js
__turbopack_context__.s({
    "default": (()=>CatalogueFilter)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/app/catalogue/catalog-filter/CatalogueFilter.module.css [app-ssr] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/plus.js [app-ssr] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fa/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
function CatalogueFilter() {
    const [filters, setFilters] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        {
            id: "#301012",
            name: "Electronics In Stock",
            criteria: "Smart Devices & Innovation",
            createdBy: "Alex Johnson",
            productCount: "1900",
            selected: false
        },
        {
            id: "#301011",
            name: "Home Appliances Available",
            criteria: "Tech/Next",
            createdBy: "Emily Davis",
            productCount: "1600",
            selected: false
        },
        {
            id: "#301002",
            name: "Gadgets On Sale",
            criteria: "Tech/Next",
            createdBy: "Michael Brown",
            productCount: "1700",
            selected: false
        },
        {
            id: "#301001",
            name: "Latest Smartphones",
            criteria: "Tech/Next",
            createdBy: "Sarah Wilson",
            productCount: "1800",
            selected: false
        },
        {
            id: "#301000",
            name: "Laptops and Notebooks",
            criteria: "Tech/Next",
            createdBy: "David Lee",
            productCount: "1900",
            selected: false
        },
        {
            id: "#301800",
            name: "Wearable Tech Items",
            criteria: "Tech/Next",
            createdBy: "Jessica Taylor",
            productCount: "2000",
            selected: false
        },
        {
            id: "#301701",
            name: "Smart Home Devices",
            criteria: "Tech/Next",
            createdBy: "Daniel Martinez",
            productCount: "2100",
            selected: false
        },
        {
            id: "#301600",
            name: "Gaming Consoles",
            criteria: "Tech/Next",
            createdBy: "Laura Anderson",
            productCount: "2200",
            selected: false
        },
        {
            id: "#301500",
            name: "Audio Equipment",
            criteria: "Tech/Next",
            createdBy: "James Thomas",
            productCount: "2300",
            selected: false
        },
        {
            id: "#301400",
            name: "Computer Accessories",
            criteria: "Tech/Next",
            createdBy: "Sophia White",
            productCount: "2400",
            selected: false
        }
    ]);
    const [activeMenu, setActiveMenu] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(1);
    const [itemsPerPage, setItemsPerPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(10);
    const handleCheckboxChange = (id)=>{
        setFilters(filters.map((filter)=>filter.id === id ? {
                ...filter,
                selected: !filter.selected
            } : filter));
    };
    const toggleMenu = (id)=>{
        if (activeMenu === id) {
            setActiveMenu(null);
        } else {
            setActiveMenu(id);
        }
    };
    const handleMenuAction = (action, id)=>{
        console.log(`${action} action for filter ${id}`);
        setActiveMenu(null);
    };
    const handlePageChange = (page)=>{
        setCurrentPage(page);
    };
    // Calculate pagination
    const totalPages = Math.ceil(filters.length / itemsPerPage);
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = filters.slice(indexOfFirstItem, indexOfLastItem);
    // Import font in the head section if using Next.js pages directory
    // const addPublicSansFont = () => {
    //   return (
    //     <style jsx global>{`
    //       @import url("https://fonts.googleapis.com/css2?family=Public+Sans:wght@300;400;500;600;700&display=swap");
    //     `}</style>
    //   );
    // };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].container,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].header,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].title,
                        children: "Catalogue Filters"
                    }, void 0, false, {
                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                        lineNumber: 142,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].searchContainer,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].inputWrapper,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FaSearch"], {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].searchIcon
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 145,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        placeholder: "Search Catalog",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].searchInput
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 146,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                lineNumber: 144,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].addButton,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                        size: 20
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 154,
                                        columnNumber: 13
                                    }, this),
                                    "Catalogue"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                lineNumber: 153,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].filterOptions,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].showOptions,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "Show"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 160,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].showSelect,
                                            value: itemsPerPage,
                                            onChange: (e)=>setItemsPerPage(Number(e.target.value)),
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: 5,
                                                    children: "5"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                    lineNumber: 166,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: 10,
                                                    children: "10"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                    lineNumber: 167,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: 20,
                                                    children: "20"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                    lineNumber: 168,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: 50,
                                                    children: "50"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                    lineNumber: 169,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 161,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                    lineNumber: 159,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                lineNumber: 158,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                        lineNumber: 143,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                lineNumber: 141,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].tableContainer,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].filtersTable,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].checkboxColumn,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "checkbox",
                                                onChange: ()=>{
                                                    const allSelected = filters.every((filter)=>filter.selected);
                                                    setFilters(filters.map((filter)=>({
                                                            ...filter,
                                                            selected: !allSelected
                                                        })));
                                                },
                                                checked: filters.length > 0 && filters.every((filter)=>filter.selected)
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                lineNumber: 180,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 179,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].idColumn,
                                            children: "ID"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 199,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].nameColumn,
                                            children: "Filter Name"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 200,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].criteriaColumn,
                                            children: "Criteria"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 201,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].createdByColumn,
                                            children: "Created By"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 202,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].countColumn,
                                            children: "Product Count"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 203,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actionsColumn
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 204,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                    lineNumber: 178,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                lineNumber: 177,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                children: currentItems.map((filter)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        className: filter.selected ? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].selectedRow : "",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].checkboxColumn,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "checkbox",
                                                    checked: filter.selected,
                                                    onChange: ()=>handleCheckboxChange(filter.id)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                    lineNumber: 214,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                lineNumber: 213,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].idColumn,
                                                children: filter.id
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                lineNumber: 220,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].nameColumn,
                                                children: filter.name
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                lineNumber: 221,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].criteriaColumn,
                                                children: filter.criteria
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                lineNumber: 222,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].createdByColumn,
                                                children: filter.createdBy
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                lineNumber: 223,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].countColumn,
                                                children: filter.productCount
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                lineNumber: 224,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actionsColumn,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].menuButton,
                                                        onClick: ()=>toggleMenu(filter.id),
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].menuDots,
                                                            children: "⋮"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                            lineNumber: 230,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                        lineNumber: 226,
                                                        columnNumber: 19
                                                    }, this),
                                                    activeMenu === filter.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].menuDropdown,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                onClick: ()=>handleMenuAction("edit", filter.id),
                                                                children: "Edit"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                                lineNumber: 234,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                onClick: ()=>handleMenuAction("update", filter.id),
                                                                children: "Update"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                                lineNumber: 239,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                onClick: ()=>handleMenuAction("delete", filter.id),
                                                                children: "Delete"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                                lineNumber: 244,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                        lineNumber: 233,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                lineNumber: 225,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, filter.id, true, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 209,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                lineNumber: 207,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                        lineNumber: 176,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].pagination,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].paginationButtons,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].paginationButton,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        width: "24",
                                        height: "24",
                                        fill: "none",
                                        stroke: "currentColor",
                                        strokeWidth: "2",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                                            points: "15 18 9 12 15 6"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 270,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 260,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                    lineNumber: 259,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].paginationButton,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        width: "24",
                                        height: "24",
                                        fill: "none",
                                        stroke: "currentColor",
                                        strokeWidth: "2",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("polyline", {
                                            points: "9 18 15 12 9 6"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 284,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 274,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                    lineNumber: 273,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                            lineNumber: 258,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                        lineNumber: 257,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                lineNumber: 175,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
        lineNumber: 138,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=app_catalogue_catalog-filter_f6bdc88a._.js.map