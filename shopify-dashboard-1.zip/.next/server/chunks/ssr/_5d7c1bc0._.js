module.exports = {

"[project]/.next-internal/server/app/catalogue/your-catalog/page/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/app/layout.js [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.js [app-rsc] (ecmascript)"));
}}),
"[project]/app/catalogue/your-catalog/YourCatalogue.module.css [app-rsc] (css module)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v({
  "actions": "YourCatalogue-module__0ieiVW__actions",
  "arrowIcon": "YourCatalogue-module__0ieiVW__arrowIcon",
  "button": "YourCatalogue-module__0ieiVW__button",
  "catalogSelect": "YourCatalogue-module__0ieiVW__catalogSelect",
  "catalogueNameHeader": "YourCatalogue-module__0ieiVW__catalogueNameHeader",
  "container": "YourCatalogue-module__0ieiVW__container",
  "headerRow": "YourCatalogue-module__0ieiVW__headerRow",
  "inStock": "YourCatalogue-module__0ieiVW__inStock",
  "input": "YourCatalogue-module__0ieiVW__input",
  "lowStock": "YourCatalogue-module__0ieiVW__lowStock",
  "nameCell": "YourCatalogue-module__0ieiVW__nameCell",
  "outStock": "YourCatalogue-module__0ieiVW__outStock",
  "pagination": "YourCatalogue-module__0ieiVW__pagination",
  "plusIcon": "YourCatalogue-module__0ieiVW__plusIcon",
  "searchIcon": "YourCatalogue-module__0ieiVW__searchIcon",
  "searchWrapper": "YourCatalogue-module__0ieiVW__searchWrapper",
  "select": "YourCatalogue-module__0ieiVW__select",
  "showText": "YourCatalogue-module__0ieiVW__showText",
  "showWrapper": "YourCatalogue-module__0ieiVW__showWrapper",
  "statusBadge": "YourCatalogue-module__0ieiVW__statusBadge",
  "table": "YourCatalogue-module__0ieiVW__table",
  "tableHeaderRow": "YourCatalogue-module__0ieiVW__tableHeaderRow",
  "title": "YourCatalogue-module__0ieiVW__title",
  "verticalDots": "YourCatalogue-module__0ieiVW__verticalDots",
});
}}),
"[project]/app/images/iphone.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/iphone.163c0acc.png");}}),
"[project]/app/images/iphone.png.mjs { IMAGE => \"[project]/app/images/iphone.png (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$iphone$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/iphone.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$iphone$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 464,
    height: 580,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAYAAADaxo44AAAA00lEQVR42gHIADf/AOrr7QDp6+wA6OnrAPDw8gD29vcA8/PzAADo6+wA6evsAOPk5QDn5ecO8vLzBezs7QAA5+rrAOfo6QDNyMgYr4SDqcO4uHbe3+EOAOXo6QDk5ucFqJCUgK9ZWfuadHbiycnMMwDj5ecAvLi6QXtTVefHZGH9tpCQit7e4AcA3N/hB5yFj6CsVGz+wHJv9tjQ0Ufe3+EAAN3h4wG4ub00nHyOrL2rsYHh4uQe3eDhAADZ3eAA2t7gANDR1A3c3+EE4OLkANze4QC8Fnzsy0yHLgAAAABJRU5ErkJggg==",
    blurWidth: 6,
    blurHeight: 8
};
}}),
"[project]/app/catalogue/your-catalog/YourCatalogue.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Catalog)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/app/catalogue/your-catalog/YourCatalogue.module.css [app-rsc] (css module)");
(()=>{
    const e = new Error("Cannot find module '../../images/handmadepouch.png'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '../../images/watch.png'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '../../images/headphone.png'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$iphone$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$iphone$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/iphone.png.mjs { IMAGE => "[project]/app/images/iphone.png (static in ecmascript)" } [app-rsc] (structured image object, ecmascript)');
(()=>{
    const e = new Error("Cannot find module '../../images/pumashoes.png'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '../../images/imac.png'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '../../images/lego-car.png'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '../../images/skincare.png'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '../../images/nike.png'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
;
;
;
;
;
;
;
;
;
;
;
;
;
const catalogData = [
    {
        id: "#302012",
        name: "Handmade Pouch",
        vendor: "Acme Corp",
        category: "Electronics",
        stock: "50 units",
        status: "In-Stock",
        image: h1
    },
    {
        id: "#302011",
        name: "Smartwatch E2",
        vendor: "Tech Innovations",
        category: "Home Appliances",
        stock: "75 units",
        status: "Low Stock",
        image: Smartwatch
    },
    {
        id: "#302002",
        name: "Smartwatch E1",
        vendor: "Global Solutions",
        category: "Furniture",
        stock: "100 units",
        status: "Out-of-Stock",
        image: Smartwatch
    },
    {
        id: "#301901",
        name: "Headphone G1 Pro",
        vendor: "Eco Enterprises",
        category: "Toys",
        stock: "Weekly",
        status: "Out-of-Stock",
        image: Headphone
    },
    {
        id: "#301900",
        name: "Iphone X",
        vendor: "Smart Devices Inc.",
        category: "Books",
        stock: "150 units",
        status: "Low Stock",
        image: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$iphone$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$iphone$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: "#301800",
        name: "Puma Shoes",
        vendor: "NextGen Technologies",
        category: "Clothing",
        stock: "200 units",
        status: "Low Stock",
        image: Puma
    },
    {
        id: "#301701",
        name: "Imac 2021",
        vendor: "Cloud Services Ltd.",
        category: "Sports Equipment",
        stock: "250 units",
        status: "In-Stock",
        image: Imac
    },
    {
        id: "#301600",
        name: "Nike Shoes",
        vendor: "Digital Ventures",
        category: "Beauty Products",
        stock: "300 units",
        status: "Out-of-Stock",
        image: NikeShoes
    },
    {
        id: "#301500",
        name: "Lego Car",
        vendor: "Future Dynamics",
        category: "Automotive Accessories",
        stock: "350 units",
        status: "Out-of-Stock",
        image: LegoCar
    },
    {
        id: "#301400",
        name: "Skincare Alia 1",
        vendor: "Innovatech Solutions",
        category: "Gardening Tools",
        stock: "400 units",
        status: "In-Stock",
        image: Skincare
    }
];
const statusColor = {
    "In-Stock": __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].inStock,
    "Low Stock": __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].lowStock,
    "Out-of-Stock": __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].outStock
};
function Catalog() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].container,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].headerRow,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].title,
                        children: "Your Catalogue"
                    }, void 0, false, {
                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                        lineNumber: 121,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].actions,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].searchWrapper,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].searchIcon,
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        stroke: "currentColor",
                                        strokeWidth: 2,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            d: "M21 21l-4.35-4.35m0 0A7.5 7.5 0 1110.5 3a7.5 7.5 0 016.15 13.65z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 132,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 124,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        placeholder: "Search Catalog",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].input
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 138,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                lineNumber: 123,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].select} ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].catalogSelect}`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    children: "All Catalog"
                                }, void 0, false, {
                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                    lineNumber: 145,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                lineNumber: 144,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].button,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].plusIcon,
                                        children: "+"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 148,
                                        columnNumber: 13
                                    }, this),
                                    " Catalogue"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                lineNumber: 147,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].showWrapper,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].showText,
                                        children: "Show"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 151,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].select,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            children: "10"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 153,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 152,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                lineNumber: 150,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                        lineNumber: 122,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                lineNumber: 120,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].table,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].tableHeaderRow,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "checkbox"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 162,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                    lineNumber: 161,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                    children: "ID"
                                }, void 0, false, {
                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                    lineNumber: 164,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].catalogueNameHeader,
                                    children: [
                                        "Catalogue Name",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            width: "18",
                                            height: "18",
                                            viewBox: "0 0 18 18",
                                            fill: "none",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                d: "M4.81 6.75h8.38c.15 0 .3.04.42.13.12.08.22.2.28.34.06.13.08.28.05.42-.03.15-.1.28-.2.39L9.53 12.22c-.14.14-.33.22-.53.22s-.39-.08-.53-.22L4.28 8.03c-.1-.1-.17-.24-.2-.39a.75.75 0 01.47-.88c.12-.09.27-.13.43-.13Z",
                                                fill: "#8E95A6"
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                lineNumber: 174,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 167,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                    lineNumber: 165,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                    children: "Vendor"
                                }, void 0, false, {
                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                    lineNumber: 180,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                    children: "Category"
                                }, void 0, false, {
                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                    lineNumber: 181,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                    children: "Stock"
                                }, void 0, false, {
                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                    lineNumber: 182,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                    children: "Status"
                                }, void 0, false, {
                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                    lineNumber: 183,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {}, void 0, false, {
                                    fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                    lineNumber: 184,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                            lineNumber: 160,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                        lineNumber: 159,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                        children: catalogData.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "checkbox"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 191,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 190,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        children: item.id
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 193,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].nameCell,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                                src: item.image,
                                                alt: item.name,
                                                width: 30,
                                                height: 30
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                                lineNumber: 195,
                                                columnNumber: 17
                                            }, this),
                                            item.name
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 194,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        children: item.vendor
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 203,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        children: item.category
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 204,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        children: item.stock
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 205,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusBadge} ${statusColor[item.status]}`,
                                            children: item.status
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                            lineNumber: 207,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 206,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].verticalDots,
                                        children: "⋮"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                        lineNumber: 215,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, index, true, {
                                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                                lineNumber: 189,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                        lineNumber: 187,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                lineNumber: 158,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].pagination,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        children: "<"
                    }, void 0, false, {
                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                        lineNumber: 221,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        children: ">"
                    }, void 0, false, {
                        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                        lineNumber: 222,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
                lineNumber: 220,
                columnNumber: 7
            }, this),
            "   "
        ]
    }, void 0, true, {
        fileName: "[project]/app/catalogue/your-catalog/YourCatalogue.js",
        lineNumber: 119,
        columnNumber: 5
    }, this);
}
}}),
"[project]/app/catalogue/your-catalog/page.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>YourCataloguePage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/catalogue/your-catalog/YourCatalogue.js [app-rsc] (ecmascript)");
;
;
function YourCataloguePage() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$YourCatalogue$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/app/catalogue/your-catalog/page.js",
        lineNumber: 6,
        columnNumber: 10
    }, this);
}
}}),
"[project]/app/catalogue/your-catalog/page.js [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/catalogue/your-catalog/page.js [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=_5d7c1bc0._.js.map