module.exports = {

"[project]/app/catalogue/vendor-setup/VendorSetupTable.module.css [app-ssr] (css module)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v({
  "actionsBtn": "VendorSetupTable-module__PJYpTG__actionsBtn",
  "active": "VendorSetupTable-module__PJYpTG__active",
  "addVendorBtn": "VendorSetupTable-module__PJYpTG__addVendorBtn",
  "connectionType": "VendorSetupTable-module__PJYpTG__connectionType",
  "dropdownArrow": "VendorSetupTable-module__PJYpTG__dropdownArrow",
  "entriesSelect": "VendorSetupTable-module__PJYpTG__entriesSelect",
  "green": "VendorSetupTable-module__PJYpTG__green",
  "headerWrapper": "VendorSetupTable-module__PJYpTG__headerWrapper",
  "inactive": "VendorSetupTable-module__PJYpTG__inactive",
  "orange": "VendorSetupTable-module__PJYpTG__orange",
  "plusIcon": "VendorSetupTable-module__PJYpTG__plusIcon",
  "progressBar": "VendorSetupTable-module__PJYpTG__progressBar",
  "progressBarContainer": "VendorSetupTable-module__PJYpTG__progressBarContainer",
  "progressInfo": "VendorSetupTable-module__PJYpTG__progressInfo",
  "progressPercentage": "VendorSetupTable-module__PJYpTG__progressPercentage",
  "progressText": "VendorSetupTable-module__PJYpTG__progressText",
  "red": "VendorSetupTable-module__PJYpTG__red",
  "searchContainer": "VendorSetupTable-module__PJYpTG__searchContainer",
  "searchIcon": "VendorSetupTable-module__PJYpTG__searchIcon",
  "searchInput": "VendorSetupTable-module__PJYpTG__searchInput",
  "showEntries": "VendorSetupTable-module__PJYpTG__showEntries",
  "statusBadge": "VendorSetupTable-module__PJYpTG__statusBadge",
  "vendorActions": "VendorSetupTable-module__PJYpTG__vendorActions",
  "vendorHeader": "VendorSetupTable-module__PJYpTG__vendorHeader",
  "vendorInitial": "VendorSetupTable-module__PJYpTG__vendorInitial",
  "vendorInitialCell": "VendorSetupTable-module__PJYpTG__vendorInitialCell",
  "vendorNameCell": "VendorSetupTable-module__PJYpTG__vendorNameCell",
  "vendorNameCol": "VendorSetupTable-module__PJYpTG__vendorNameCol",
  "vendorSetupContainer": "VendorSetupTable-module__PJYpTG__vendorSetupContainer",
  "vendorTable": "VendorSetupTable-module__PJYpTG__vendorTable",
  "vendorTableContainer": "VendorSetupTable-module__PJYpTG__vendorTableContainer",
});
}}),
"[project]/app/catalogue/vendor-setup/VendorSetupTable.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>VendorSetup)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/app/catalogue/vendor-setup/VendorSetupTable.module.css [app-ssr] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function VendorSetup() {
    const [searchTerm, setSearchTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [showEntries, setShowEntries] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(10);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const vendors = [
        {
            id: 1,
            initial: "A",
            name: "Acme Corp",
            connectionType: "FTP",
            productsImported: 1500,
            percentage: 70,
            lastSync: "2025-05-13, 8:00 AM",
            status: "Active"
        },
        {
            id: 2,
            initial: "B",
            name: "Beta Innovations",
            connectionType: "SFTP",
            productsImported: 1200,
            percentage: 65,
            lastSync: "2025-05-15, 8:00 AM",
            status: "Active"
        },
        {
            id: 3,
            initial: "G",
            name: "Gamma Solutions",
            connectionType: "FTP",
            productsImported: 200,
            percentage: 80,
            lastSync: "2025-05-18, 8:00 AM",
            status: "Inactive"
        },
        {
            id: 4,
            initial: "D",
            name: "Delta Technologies",
            connectionType: "FTP",
            productsImported: 1800,
            percentage: 30,
            lastSync: "2025-05-10, 8:00 AM",
            status: "Inactive"
        }
    ];
    const getProgressBarColor = (status, percentage)=>{
        if (status === "Active") {
            return percentage >= 70 ? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].green : __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].red;
        } else {
            return __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].orange;
        }
    };
    const handleAddUser = ()=>{
        router.push("/admin/catalogue/addvendor");
    };
    const filteredVendors = vendors.filter((v)=>v.name.toLowerCase().includes(searchTerm.toLowerCase())).slice(0, showEntries);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].vendorSetupContainer,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].headerWrapper,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].vendorSetupHeaderContainer,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].vendorHeader,
                        style: {
                            minHeight: "64px",
                            alignItems: "center"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                children: "Vendor Setup"
                            }, void 0, false, {
                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                lineNumber: 77,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].vendorActions,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].searchContainer,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].searchIcon,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    width: "16",
                                                    height: "16",
                                                    viewBox: "0 0 24 24",
                                                    fill: "none",
                                                    stroke: "currentColor",
                                                    strokeWidth: "2",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                            cx: "11",
                                                            cy: "11",
                                                            r: "8"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                            lineNumber: 92,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                                            x1: "21",
                                                            y1: "21",
                                                            x2: "16.65",
                                                            y2: "16.65"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                            lineNumber: 93,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                    lineNumber: 81,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                lineNumber: 80,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                placeholder: "Search Vendor Name",
                                                value: searchTerm,
                                                onChange: (e)=>setSearchTerm(e.target.value),
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].searchInput
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                lineNumber: 96,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                        lineNumber: 79,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].addVendorBtn,
                                        onClick: handleAddUser,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].plusIcon,
                                                children: "+"
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                lineNumber: 106,
                                                columnNumber: 17
                                            }, this),
                                            " Add Vendor"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                        lineNumber: 105,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].showEntries,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "Show"
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                lineNumber: 110,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                value: showEntries,
                                                onChange: (e)=>setShowEntries(parseInt(e.target.value)),
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].entriesSelect,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: 10,
                                                        children: "10"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                        lineNumber: 116,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: 25,
                                                        children: "25"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                        lineNumber: 117,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: 50,
                                                        children: "50"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                        lineNumber: 118,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: 100,
                                                        children: "100"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                        lineNumber: 119,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                lineNumber: 111,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                        lineNumber: 109,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                lineNumber: 78,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                        lineNumber: 73,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                    lineNumber: 72,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                lineNumber: 71,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].vendorTableContainer,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].vendorTable,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        style: {
                                            width: "50px"
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                        lineNumber: 131,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].vendorNameCol,
                                        children: "Vendor Name"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                        lineNumber: 132,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        children: "Connection Type"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                        lineNumber: 133,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        children: "Progress"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                        lineNumber: 134,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        children: "Last Sync"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                        lineNumber: 135,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        children: "Status"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                        lineNumber: 136,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {}, void 0, false, {
                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                        lineNumber: 137,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                lineNumber: 130,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                            lineNumber: 129,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                            children: filteredVendors.map((vendor)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].vendorInitialCell,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].vendorInitial,
                                                children: vendor.initial
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                lineNumber: 144,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                            lineNumber: 143,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].vendorNameCell,
                                            children: vendor.name
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                            lineNumber: 146,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].connectionType,
                                                children: [
                                                    vendor.connectionType,
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].dropdownArrow,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            width: "20",
                                                            height: "20",
                                                            viewBox: "0 0 20 20",
                                                            fill: "none",
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                d: "M6.27337 8H13.7267C13.8586 8.00055 13.9873 8.04019 14.0966 8.1139C14.2059 8.18761 14.2909 8.29208 14.3409 8.4141C14.3908 8.53612 14.4035 8.67021 14.3772 8.79942C14.351 8.92863 14.287 9.04715 14.1934 9.14L10.4734 12.86C10.4114 12.9225 10.3377 12.9721 10.2564 13.0059C10.1752 13.0398 10.088 13.0572 10 13.0572C9.91203 13.0572 9.82489 13.0398 9.74365 13.0059C9.66241 12.9721 9.58868 12.9225 9.5267 12.86L5.8067 9.14C5.71309 9.04715 5.64911 8.92863 5.62285 8.79942C5.59659 8.67021 5.60924 8.53612 5.65919 8.4141C5.70914 8.29208 5.79415 8.18761 5.90347 8.1139C6.0128 8.04019 6.14152 8.00055 6.27337 8Z",
                                                                fill: "#727A90"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                                lineNumber: 158,
                                                                columnNumber: 25
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                            lineNumber: 151,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                        lineNumber: 150,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                lineNumber: 148,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                            lineNumber: 147,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].progressInfo,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].progressText,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: "Total Product Imported"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                                lineNumber: 169,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: vendor.productsImported
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                                lineNumber: 170,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                        lineNumber: 168,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].progressBarContainer,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].progressBar} ${getProgressBarColor(vendor.status, vendor.percentage)}`,
                                                            style: {
                                                                width: `${vendor.percentage}%`
                                                            }
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                            lineNumber: 173,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                        lineNumber: 172,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].progressPercentage,
                                                        children: [
                                                            vendor.percentage,
                                                            "%"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                        lineNumber: 181,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                lineNumber: 167,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                            lineNumber: 166,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            children: vendor.lastSync
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                            lineNumber: 186,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].statusBadge} ${vendor.status.toLowerCase() === "active" ? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].active : __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].inactive}`,
                                                children: vendor.status
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                lineNumber: 188,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                            lineNumber: 187,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$vendor$2d$setup$2f$VendorSetupTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actionsBtn,
                                                children: "⋮"
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                                lineNumber: 199,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                            lineNumber: 198,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, vendor.id, true, {
                                    fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                                    lineNumber: 142,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                            lineNumber: 140,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                    lineNumber: 128,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
                lineNumber: 127,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/catalogue/vendor-setup/VendorSetupTable.js",
        lineNumber: 70,
        columnNumber: 5
    }, this);
}
}}),
"[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/navigation.js [app-ssr] (ecmascript)");
}}),

};

//# sourceMappingURL=_6a9fa0eb._.js.map