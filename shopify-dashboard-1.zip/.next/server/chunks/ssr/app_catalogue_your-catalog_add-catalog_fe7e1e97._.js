module.exports = {

"[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.module.css [app-ssr] (css module)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v({
  "actionButtons": "AddCatalog-module__PDmXlG__actionButtons",
  "addButton": "AddCatalog-module__PDmXlG__addButton",
  "cancelButton": "AddCatalog-module__PDmXlG__cancelButton",
  "container": "AddCatalog-module__PDmXlG__container",
  "form": "AddCatalog-module__PDmXlG__form",
  "formGrid": "AddCatalog-module__PDmXlG__formGrid",
  "formRow": "AddCatalog-module__PDmXlG__formRow",
  "header": "AddCatalog-module__PDmXlG__header",
  "imageContent": "AddCatalog-module__PDmXlG__imageContent",
  "imageSubtext": "AddCatalog-module__PDmXlG__imageSubtext",
  "imageText": "AddCatalog-module__PDmXlG__imageText",
  "imageUpload": "AddCatalog-module__PDmXlG__imageUpload",
  "imageWithSelectsSection": "AddCatalog-module__PDmXlG__imageWithSelectsSection",
  "input": "AddCatalog-module__PDmXlG__input",
  "inputGroup": "AddCatalog-module__PDmXlG__inputGroup",
  "label": "AddCatalog-module__PDmXlG__label",
  "select": "AddCatalog-module__PDmXlG__select",
  "selectArrow": "AddCatalog-module__PDmXlG__selectArrow",
  "selectRow": "AddCatalog-module__PDmXlG__selectRow",
  "selectWrapper": "AddCatalog-module__PDmXlG__selectWrapper",
  "selectsContainer": "AddCatalog-module__PDmXlG__selectsContainer",
  "title": "AddCatalog-module__PDmXlG__title",
  "uploadIcon": "AddCatalog-module__PDmXlG__uploadIcon",
});
}}),
"[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>AddCatalog)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.module.css [app-ssr] (css module)");
"use client";
;
;
;
function AddCatalog() {
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        catalogueName: "",
        vendorName: "",
        description: "",
        stockLevel: "",
        category: "",
        subCategory: "",
        unitOfMeasure: "",
        countryOfOrigin: ""
    });
    const handleInputChange = (e)=>{
        const { name, value } = e.target;
        setFormData((prev)=>({
                ...prev,
                [name]: value
            }));
    };
    const handleSubmit = (e)=>{
        e.preventDefault();
        console.log("Form submitted:", formData);
    };
    const handleCancel = ()=>{
        console.log("Form cancelled");
    };
    const handleImageUpload = ()=>{
        console.log("Image upload clicked");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].container,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].header,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].title,
                    children: "Add Catalog"
                }, void 0, false, {
                    fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                    lineNumber: 41,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                lineNumber: 40,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                onSubmit: handleSubmit,
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].form,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].formGrid,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].formRow,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].inputGroup,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].label,
                                                children: "Catalogue Name"
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                lineNumber: 47,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                name: "catalogueName",
                                                placeholder: "Catalogue Name",
                                                value: formData.catalogueName,
                                                onChange: handleInputChange,
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].input
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                lineNumber: 48,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                        lineNumber: 46,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].inputGroup,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].label,
                                                children: "Vendor Name"
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                lineNumber: 58,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                name: "vendorName",
                                                placeholder: "Manufacturer",
                                                value: formData.vendorName,
                                                onChange: handleInputChange,
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].input
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                lineNumber: 59,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                        lineNumber: 57,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                lineNumber: 45,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].formRow,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].inputGroup,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].label,
                                                children: "Description"
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                lineNumber: 73,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                name: "description",
                                                placeholder: "Description",
                                                value: formData.description,
                                                onChange: handleInputChange,
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].input
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                lineNumber: 74,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                        lineNumber: 72,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].inputGroup,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].label,
                                                children: "Stock Level"
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                lineNumber: 84,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                name: "stockLevel",
                                                placeholder: "Stock Level",
                                                value: formData.stockLevel,
                                                onChange: handleInputChange,
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].input
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                lineNumber: 85,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                        lineNumber: 83,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                lineNumber: 71,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].imageWithSelectsSection,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].imageUpload,
                                        onClick: handleImageUpload,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].imageContent,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].uploadIcon,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            width: "33",
                                                            height: "33",
                                                            viewBox: "0 0 33 33",
                                                            fill: "none",
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                fillRule: "evenodd",
                                                                clipRule: "evenodd",
                                                                d: "M16.2231 2.29195e-07C16.3865 -0.000103767 16.548 0.035184 16.6965 0.103437C16.845 0.171691 16.9769 0.271291 17.0833 0.39539L21.6106 5.67731C21.8059 5.90545 21.9026 6.20184 21.8794 6.50127C21.8562 6.8007 21.715 7.07865 21.4869 7.27396C21.2587 7.46928 20.9623 7.56597 20.6629 7.54277C20.3635 7.51956 20.0855 7.37836 19.8902 7.15022L17.3549 4.19234V20.7504C17.3549 21.0506 17.2356 21.3385 17.0234 21.5507C16.8111 21.763 16.5232 21.8823 16.2231 21.8823C15.9229 21.8823 15.635 21.763 15.4227 21.5507C15.2105 21.3385 15.0912 21.0506 15.0912 20.7504V4.19083L12.5559 7.15022C12.4592 7.26318 12.3412 7.35599 12.2086 7.42334C12.076 7.4907 11.9315 7.53128 11.7832 7.54277C11.6349 7.55426 11.4859 7.53643 11.3445 7.49031C11.2031 7.44419 11.0722 7.37068 10.9592 7.27396C10.8463 7.17725 10.7535 7.05924 10.6861 6.92666C10.6188 6.79408 10.5782 6.64953 10.5667 6.50127C10.5552 6.35301 10.573 6.20393 10.6191 6.06256C10.6653 5.92118 10.7388 5.79028 10.8355 5.67731L15.3629 0.39539C15.4692 0.271291 15.6011 0.171691 15.7496 0.103437C15.8981 0.035184 16.0596 -0.000103767 16.2231 2.29195e-07ZM8.67141 10.5669C8.97159 10.5653 9.26012 10.683 9.47351 10.8941C9.6869 11.1052 9.80769 11.3925 9.80929 11.6927C9.81089 11.9929 9.69318 12.2814 9.48205 12.4948C9.27092 12.7082 8.98367 12.8289 8.68348 12.8305C7.03401 12.8396 5.86444 12.8819 4.97557 13.0448C4.12141 13.2033 3.62491 13.4553 3.25819 13.822C2.84017 14.2401 2.56852 14.8271 2.41912 15.9348C2.2667 17.0742 2.26368 18.5848 2.26368 20.7504V22.2595C2.26368 24.4266 2.2667 25.9373 2.41912 27.0767C2.56852 28.1843 2.84168 28.7699 3.25819 29.1894C3.67622 29.6059 4.26176 29.8776 5.37096 30.027C6.50884 30.1809 8.02098 30.1824 10.1866 30.1824H22.2595C24.4251 30.1824 25.9358 30.1809 27.0767 30.027C28.1843 29.8776 28.7699 29.6059 29.1879 29.1879C29.6059 28.7699 29.8776 28.1843 30.027 27.0767C30.1794 25.9373 30.1824 24.4266 30.1824 22.2595V20.7504C30.1824 18.5848 30.1794 17.0742 30.027 15.9333C29.8776 14.8271 29.6044 14.2401 29.1879 13.822C28.8197 13.4553 28.3247 13.2033 27.4705 13.0448C26.5817 12.8819 25.4121 12.8396 23.7626 12.8305C23.614 12.8298 23.467 12.7997 23.3299 12.7421C23.1929 12.6845 23.0686 12.6004 22.9641 12.4948C22.8595 12.3891 22.7768 12.2639 22.7207 12.1263C22.6645 11.9886 22.636 11.8413 22.6368 11.6927C22.6376 11.544 22.6677 11.397 22.7253 11.26C22.7829 11.123 22.8669 10.9986 22.9726 10.8941C23.0783 10.7896 23.2035 10.7069 23.3411 10.6507C23.4787 10.5946 23.6261 10.5661 23.7747 10.5669C25.4076 10.5759 26.7673 10.6152 27.8795 10.8189C29.0234 11.0302 29.9968 11.4301 30.7891 12.2224C31.6976 13.1294 32.0869 14.2748 32.271 15.633C32.4461 16.9399 32.4461 18.6044 32.4461 20.6674V22.3425C32.4461 24.407 32.4461 26.0701 32.271 27.3785C32.0869 28.7367 31.6976 29.8806 30.7891 30.7891C29.8806 31.6976 28.7367 32.0869 27.3785 32.271C26.0701 32.4461 24.4055 32.4461 22.3425 32.4461H10.1036C8.0406 32.4461 6.37604 32.4461 5.06763 32.271C3.70942 32.0884 2.56551 31.6976 1.65702 30.7891C0.748524 29.8806 0.359171 28.7367 0.176567 27.3785C-2.24877e-08 26.0701 0 24.4055 0 22.3425V20.6674C0 18.6044 -2.24877e-08 16.9399 0.176567 15.6315C0.357662 14.2733 0.750033 13.1294 1.65702 12.2209C2.4493 11.4301 3.42269 11.0287 4.5666 10.8189C5.67882 10.6152 7.03854 10.5759 8.67141 10.5669Z",
                                                                fill: "#ABAFB1"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                lineNumber: 107,
                                                                columnNumber: 21
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                            lineNumber: 100,
                                                            columnNumber: 19
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                        lineNumber: 99,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].imageText,
                                                        children: "Images"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                        lineNumber: 115,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                lineNumber: 98,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].imageSubtext,
                                                children: "PNG/JPG, max 5MB."
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                lineNumber: 117,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                        lineNumber: 97,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].selectsContainer,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].selectRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].inputGroup,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].selectWrapper,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                    name: "category",
                                                                    value: formData.category,
                                                                    onChange: handleInputChange,
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].select,
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "",
                                                                            children: "Category"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 130,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "electronics",
                                                                            children: "Electronics"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 131,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "clothing",
                                                                            children: "Clothing"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 132,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "books",
                                                                            children: "Books"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 133,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "home",
                                                                            children: "Home & Garden"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 134,
                                                                            columnNumber: 23
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                    lineNumber: 124,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].selectArrow,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                        width: "13",
                                                                        height: "7",
                                                                        viewBox: "0 0 13 7",
                                                                        fill: "none",
                                                                        xmlns: "http://www.w3.org/2000/svg",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                            d: "M1.75837 0.453613H11.2421C11.4099 0.453649 11.574 0.503454 11.7136 0.596733C11.8531 0.690011 11.9619 0.822575 12.0262 0.977665C12.0904 1.13276 12.1072 1.30341 12.0745 1.46805C12.0417 1.63269 11.9609 1.78393 11.8422 1.90265L7.10037 6.64449C6.94118 6.80363 6.72531 6.89303 6.50021 6.89303C6.27512 6.89303 6.05924 6.80363 5.90006 6.64449L1.15821 1.90265C1.03953 1.78393 0.958709 1.63269 0.925969 1.46805C0.89323 1.30341 0.910041 1.13276 0.974276 0.977665C1.03851 0.822575 1.14729 0.690011 1.28685 0.596733C1.42641 0.503454 1.5905 0.453649 1.75837 0.453613Z",
                                                                            fill: "#3D3C3C"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 144,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                        lineNumber: 137,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                    lineNumber: 136,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                            lineNumber: 123,
                                                            columnNumber: 19
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                        lineNumber: 122,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].inputGroup,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].selectWrapper,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                    name: "subCategory",
                                                                    value: formData.subCategory,
                                                                    onChange: handleInputChange,
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].select,
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "",
                                                                            children: "Sub-Category"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 160,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "phones",
                                                                            children: "Phones"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 161,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "laptops",
                                                                            children: "Laptops"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 162,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "tablets",
                                                                            children: "Tablets"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 163,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "accessories",
                                                                            children: "Accessories"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 164,
                                                                            columnNumber: 23
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                    lineNumber: 154,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].selectArrow,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                        width: "13",
                                                                        height: "7",
                                                                        viewBox: "0 0 13 7",
                                                                        fill: "none",
                                                                        xmlns: "http://www.w3.org/2000/svg",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                            d: "M1.75837 0.453613H11.2421C11.4099 0.453649 11.574 0.503454 11.7136 0.596733C11.8531 0.690011 11.9619 0.822575 12.0262 0.977665C12.0904 1.13276 12.1072 1.30341 12.0745 1.46805C12.0417 1.63269 11.9609 1.78393 11.8422 1.90265L7.10037 6.64449C6.94118 6.80363 6.72531 6.89303 6.50021 6.89303C6.27512 6.89303 6.05924 6.80363 5.90006 6.64449L1.15821 1.90265C1.03953 1.78393 0.958709 1.63269 0.925969 1.46805C0.89323 1.30341 0.910041 1.13276 0.974276 0.977665C1.03851 0.822575 1.14729 0.690011 1.28685 0.596733C1.42641 0.503454 1.5905 0.453649 1.75837 0.453613Z",
                                                                            fill: "#3D3C3C"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 174,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                        lineNumber: 167,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                    lineNumber: 166,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                            lineNumber: 153,
                                                            columnNumber: 19
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                        lineNumber: 152,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                lineNumber: 121,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].selectRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].inputGroup,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].selectWrapper,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                    name: "unitOfMeasure",
                                                                    value: formData.unitOfMeasure,
                                                                    onChange: handleInputChange,
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].select,
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "",
                                                                            children: "Unit of Measure"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 193,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "pieces",
                                                                            children: "Pieces"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 194,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "kg",
                                                                            children: "Kilograms"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 195,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "lbs",
                                                                            children: "Pounds"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 196,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "liters",
                                                                            children: "Liters"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 197,
                                                                            columnNumber: 23
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                    lineNumber: 187,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].selectArrow,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                        width: "13",
                                                                        height: "7",
                                                                        viewBox: "0 0 13 7",
                                                                        fill: "none",
                                                                        xmlns: "http://www.w3.org/2000/svg",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                            d: "M1.75837 0.453613H11.2421C11.4099 0.453649 11.574 0.503454 11.7136 0.596733C11.8531 0.690011 11.9619 0.822575 12.0262 0.977665C12.0904 1.13276 12.1072 1.30341 12.0745 1.46805C12.0417 1.63269 11.9609 1.78393 11.8422 1.90265L7.10037 6.64449C6.94118 6.80363 6.72531 6.89303 6.50021 6.89303C6.27512 6.89303 6.05924 6.80363 5.90006 6.64449L1.15821 1.90265C1.03953 1.78393 0.958709 1.63269 0.925969 1.46805C0.89323 1.30341 0.910041 1.13276 0.974276 0.977665C1.03851 0.822575 1.14729 0.690011 1.28685 0.596733C1.42641 0.503454 1.5905 0.453649 1.75837 0.453613Z",
                                                                            fill: "#3D3C3C"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 207,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                        lineNumber: 200,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                    lineNumber: 199,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                            lineNumber: 186,
                                                            columnNumber: 19
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                        lineNumber: 185,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].inputGroup,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].selectWrapper,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                    name: "countryOfOrigin",
                                                                    value: formData.countryOfOrigin,
                                                                    onChange: handleInputChange,
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].select,
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "",
                                                                            children: "Country of Origin"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 223,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "US",
                                                                            children: "United States"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 224,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "CN",
                                                                            children: "China"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 225,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "DE",
                                                                            children: "Germany"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 226,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                            value: "JP",
                                                                            children: "Japan"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 227,
                                                                            columnNumber: 23
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                    lineNumber: 217,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].selectArrow,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                        width: "13",
                                                                        height: "7",
                                                                        viewBox: "0 0 13 7",
                                                                        fill: "none",
                                                                        xmlns: "http://www.w3.org/2000/svg",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                            d: "M1.75837 0.453613H11.2421C11.4099 0.453649 11.574 0.503454 11.7136 0.596733C11.8531 0.690011 11.9619 0.822575 12.0262 0.977665C12.0904 1.13276 12.1072 1.30341 12.0745 1.46805C12.0417 1.63269 11.9609 1.78393 11.8422 1.90265L7.10037 6.64449C6.94118 6.80363 6.72531 6.89303 6.50021 6.89303C6.27512 6.89303 6.05924 6.80363 5.90006 6.64449L1.15821 1.90265C1.03953 1.78393 0.958709 1.63269 0.925969 1.46805C0.89323 1.30341 0.910041 1.13276 0.974276 0.977665C1.03851 0.822575 1.14729 0.690011 1.28685 0.596733C1.42641 0.503454 1.5905 0.453649 1.75837 0.453613Z",
                                                                            fill: "#3D3C3C"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                            lineNumber: 237,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                        lineNumber: 230,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                                    lineNumber: 229,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                            lineNumber: 216,
                                                            columnNumber: 19
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                        lineNumber: 215,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                                lineNumber: 184,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                        lineNumber: 120,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                lineNumber: 96,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                        lineNumber: 44,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actionButtons,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: handleCancel,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].cancelButton,
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                lineNumber: 252,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$your$2d$catalog$2f$add$2d$catalog$2f$AddCatalog$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].addButton,
                                children: "Add"
                            }, void 0, false, {
                                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                                lineNumber: 259,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                        lineNumber: 251,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
                lineNumber: 43,
                columnNumber: 7
            }, this),
            " "
        ]
    }, void 0, true, {
        fileName: "[project]/app/catalogue/your-catalog/add-catalog/AddCatalog.js",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=app_catalogue_your-catalog_add-catalog_fe7e1e97._.js.map