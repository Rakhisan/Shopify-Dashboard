module.exports = {

"[project]/.next-internal/server/app/export/export-dashboard/page/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/app/layout.js [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.js [app-rsc] (ecmascript)"));
}}),
"[project]/app/export/export-dashboard/ExportImportDashboard.module.css [app-rsc] (css module)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v({
  "buttonGroup": "ExportImportDashboard-module__juX5-W__buttonGroup",
  "card": "ExportImportDashboard-module__juX5-W__card",
  "cardsContainer": "ExportImportDashboard-module__juX5-W__cardsContainer",
  "checkHistoryButton": "ExportImportDashboard-module__juX5-W__checkHistoryButton",
  "companyName": "ExportImportDashboard-module__juX5-W__companyName",
  "completed": "ExportImportDashboard-module__juX5-W__completed",
  "configButton": "ExportImportDashboard-module__juX5-W__configButton",
  "container": "ExportImportDashboard-module__juX5-W__container",
  "failed": "ExportImportDashboard-module__juX5-W__failed",
  "inProgress": "ExportImportDashboard-module__juX5-W__inProgress",
  "logo": "ExportImportDashboard-module__juX5-W__logo",
  "logoContainer": "ExportImportDashboard-module__juX5-W__logoContainer",
  "logsButton": "ExportImportDashboard-module__juX5-W__logsButton",
  "pending": "ExportImportDashboard-module__juX5-W__pending",
  "section": "ExportImportDashboard-module__juX5-W__section",
  "sectionHeader": "ExportImportDashboard-module__juX5-W__sectionHeader",
  "sectionTitle": "ExportImportDashboard-module__juX5-W__sectionTitle",
  "seeDetailsButton": "ExportImportDashboard-module__juX5-W__seeDetailsButton",
  "seeMoreButton": "ExportImportDashboard-module__juX5-W__seeMoreButton",
  "statusDetails": "ExportImportDashboard-module__juX5-W__statusDetails",
  "statusLabel": "ExportImportDashboard-module__juX5-W__statusLabel",
  "statusRow": "ExportImportDashboard-module__juX5-W__statusRow",
  "statusTag": "ExportImportDashboard-module__juX5-W__statusTag",
  "statusValue": "ExportImportDashboard-module__juX5-W__statusValue",
  "success": "ExportImportDashboard-module__juX5-W__success",
  "viewErrorsButton": "ExportImportDashboard-module__juX5-W__viewErrorsButton",
});
}}),
"[project]/app/images/logo_amazon.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/logo_amazon.bebc4d50.png");}}),
"[project]/app/images/logo_amazon.png.mjs { IMAGE => \"[project]/app/images/logo_amazon.png (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_amazon$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/logo_amazon.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_amazon$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 161,
    height: 64,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAbklEQVR42gFjAJz/ABYWFlEVFRVdGBgYZBgYGFgVFRVTFxcXWRcXF1wVFRVeABsbGmAqIxhsIRwTZCEfGmw6LhpzLiYaaRgYGGMRERFaAAICAQMfFAIWSS0BP08wAklLMAQ0GxEDEgEBAQIBAQEC7wMNukS47DIAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 3
};
}}),
"[project]/app/images/logo_google.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/logo_google.34c759c0.png");}}),
"[project]/app/images/logo_google.png.mjs { IMAGE => \"[project]/app/images/logo_google.png (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_google$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/logo_google.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_google$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 141,
    height: 47,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAbklEQVR42gFjAJz/ABk+c2MULFFFJQoMIiIQBxwiGw0fChgpJRY+K1ErDAomABY3ZVckOmlkcx8nb4Q/HW9xXDVxJEl6cEZbWJKcIR6CAAwdNi4PHDQvOQwNMDgbDC05MCA7H0qFdB8xPUxFDg033YoU4v8ffKoAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 3
};
}}),
"[project]/app/images/logo_walmart.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/logo_walmart.1db54eeb.png");}}),
"[project]/app/images/logo_walmart.png.mjs { IMAGE => \"[project]/app/images/logo_walmart.png (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_walmart$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/logo_walmart.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_walmart$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 215,
    height: 56,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAATUlEQVR42gFCAL3/AAArUlEAJkhFACE/QQAcNDEAHTc0ByE0N0IvAjNJNAE3AAAuWFcANGFfADFaXQArUVAANGBfByY9QUQzAzZPOAA6a4oLrqNkBRAAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 2
};
}}),
"[project]/app/images/logo.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/logo.e9b821c0.png");}}),
"[project]/app/images/logo.png.mjs { IMAGE => \"[project]/app/images/logo.png (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/logo.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 141,
    height: 46,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAbklEQVR42gFjAJz/ADxKIlA6SiJcBAUDCwYFBhUCAgIHBAMDDAkJCSEDAwMJAJOraMtti0rIGhwXWR8dHngdGxxwHx0edyAeHnkTEhJHAGR2RItRajaZEhQPNw0MDDETEhJJERAQQQ8ODzoLCgopQaIRGSuvXFkAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 3
};
}}),
"[project]/app/export/export-dashboard/ExportImportDashboard.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// ExportImportDashboard.jsx
__turbopack_context__.s({
    "default": (()=>ExportImportDashboard)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/app/export/export-dashboard/ExportImportDashboard.module.css [app-rsc] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_amazon$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo_amazon$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/logo_amazon.png.mjs { IMAGE => "[project]/app/images/logo_amazon.png (static in ecmascript)" } [app-rsc] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_google$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo_google$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/logo_google.png.mjs { IMAGE => "[project]/app/images/logo_google.png (static in ecmascript)" } [app-rsc] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_walmart$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo_walmart$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/logo_walmart.png.mjs { IMAGE => "[project]/app/images/logo_walmart.png (static in ecmascript)" } [app-rsc] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/logo.png.mjs { IMAGE => "[project]/app/images/logo.png (static in ecmascript)" } [app-rsc] (structured image object, ecmascript)');
;
;
;
;
;
;
;
;
function ExportImportDashboard() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].container,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].section,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].sectionHeader,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].sectionTitle,
                                children: "Export Status"
                            }, void 0, false, {
                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                lineNumber: 16,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].buttonGroup,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].configButton,
                                        children: "Configure Export"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 18,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].logsButton,
                                        children: "View Logs"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 19,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                lineNumber: 17,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                        lineNumber: 15,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].cardsContainer,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].card,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].logoContainer,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                            src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                            alt: "Shopify",
                                            width: 150,
                                            height: 80,
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].logo
                                        }, void 0, false, {
                                            fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                            lineNumber: 27,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 26,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusDetails,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Products Exported"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 38,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "5,000 SKUs"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 39,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 37,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Last Export"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 43,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "2025-05-13, 9:00 AM"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 44,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 42,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Status"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 48,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusTag} ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].success}`,
                                                        children: "Success"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 49,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 47,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 36,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].seeMoreButton,
                                        children: "See more"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 55,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                lineNumber: 25,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].card,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].logoContainer,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                            src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_google$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo_google$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                            alt: "Google",
                                            width: 150,
                                            height: 80,
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].logo
                                        }, void 0, false, {
                                            fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                            lineNumber: 61,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 60,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusDetails,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Products Exported"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 72,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "2,000 SKUs"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 73,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 71,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Last Export"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 77,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "2025-05-14, 10:30 AM"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 78,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 76,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Status"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 82,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusTag} ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].pending}`,
                                                        children: "Pending"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 83,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 81,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 70,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].seeMoreButton,
                                        children: "See more"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 89,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                lineNumber: 59,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].card,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].logoContainer,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                            src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_amazon$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo_amazon$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                            alt: "Amazon",
                                            width: 150,
                                            height: 80,
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].logo
                                        }, void 0, false, {
                                            fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                            lineNumber: 95,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 94,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusDetails,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Products Exported"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 106,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "300 SKUs"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 107,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 105,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Last Export"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 111,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "2025-05-12, 8:15 PM"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 112,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 110,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Status"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 116,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusTag} ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].failed}`,
                                                        children: "Failed"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 117,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 115,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 104,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].seeMoreButton,
                                        children: "See more"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 123,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                lineNumber: 93,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].card,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].logoContainer,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                            src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_walmart$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo_walmart$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                            alt: "Walmart",
                                            width: 150,
                                            height: 80,
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].logo
                                        }, void 0, false, {
                                            fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                            lineNumber: 129,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 128,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusDetails,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Products Exported"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 140,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "3,500 SKUs"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 141,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 139,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Last Export"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 145,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "2025-05-15, 1:45 PM"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 146,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 144,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Status"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 150,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusTag} ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].inProgress}`,
                                                        children: "In Progress"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 151,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 149,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 138,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].seeMoreButton,
                                        children: "See more"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 157,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                lineNumber: 127,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                        lineNumber: 23,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].section,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].sectionHeader,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].sectionTitle,
                                children: "Import Status"
                            }, void 0, false, {
                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                lineNumber: 165,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].buttonGroup,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].configButton,
                                        children: "Configure Import"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 167,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].logsButton,
                                        children: "View Logs"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 168,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                lineNumber: 166,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                        lineNumber: 164,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].cardsContainer,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].card,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].companyName,
                                        children: "Acme Corp"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 175,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusDetails,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Products Exported"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 179,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "5,000 SKUs"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 180,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 178,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Last Import"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 184,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "2025-05-13, 9:00 AM"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 185,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 183,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Status"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 189,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusTag} ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].success}`,
                                                        children: "Success"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 190,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 188,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 177,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].seeMoreButton,
                                        children: "See more"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 196,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                lineNumber: 174,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].card,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].companyName,
                                        children: "Beta Innovations"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 201,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusDetails,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Products Imported"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 205,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "1,200 SKUs"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 206,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 204,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Review Process"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 210,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "2025-05-14, 10:30 AM"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 211,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 209,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Status"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 215,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusTag} ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].pending}`,
                                                        children: "Pending"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 216,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 214,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 203,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].seeDetailsButton,
                                        children: "See details"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 222,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                lineNumber: 200,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].card,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].companyName,
                                        children: "Gamma Solutions"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 227,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusDetails,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Products Imported"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 231,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "300 SKUs"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 232,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 230,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Error Log"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 236,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "2025-05-12, 4:20 PM"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 237,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 235,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Status"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 241,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusTag} ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].failed}`,
                                                        children: "Failed"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 242,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 240,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 229,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].viewErrorsButton,
                                        children: "View errors"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 248,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                lineNumber: 226,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].card,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].companyName,
                                        children: "Delta Technologies"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 253,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusDetails,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Products Imported"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 257,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "2,500 SKUs"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 258,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 256,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Last Sync"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 262,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusValue,
                                                        children: "2025-05-15, 8:45 AM"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 263,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 261,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusRow,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusLabel,
                                                        children: "Status"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 267,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].statusTag} ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].completed}`,
                                                        children: "Completed"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                        lineNumber: 268,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                                lineNumber: 266,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 255,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].checkHistoryButton,
                                        children: "Check history"
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                        lineNumber: 274,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                                lineNumber: 252,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                        lineNumber: 172,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
                lineNumber: 163,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/export/export-dashboard/ExportImportDashboard.js",
        lineNumber: 12,
        columnNumber: 5
    }, this);
}
}}),
"[project]/app/export/export-dashboard/page.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>UserTablePage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/export/export-dashboard/ExportImportDashboard.js [app-rsc] (ecmascript)");
;
;
function UserTablePage() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$export$2d$dashboard$2f$ExportImportDashboard$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/app/export/export-dashboard/page.js",
        lineNumber: 6,
        columnNumber: 10
    }, this);
}
}}),
"[project]/app/export/export-dashboard/page.js [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/export/export-dashboard/page.js [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=_f7346c68._.js.map