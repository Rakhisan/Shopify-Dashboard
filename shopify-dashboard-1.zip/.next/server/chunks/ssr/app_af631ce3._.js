module.exports = {

"[project]/app/export/import-from-channel/ImportChannel.module.css [app-ssr] (css module)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v({
  "acmeAvatar": "ImportChannel-module__oPeTaq__acmeAvatar",
  "actionButton": "ImportChannel-module__oPeTaq__actionButton",
  "actionCell": "ImportChannel-module__oPeTaq__actionCell",
  "actionColumn": "ImportChannel-module__oPeTaq__actionColumn",
  "actionMenu": "ImportChannel-module__oPeTaq__actionMenu",
  "actionMenuItem": "ImportChannel-module__oPeTaq__actionMenuItem",
  "activeBadge": "ImportChannel-module__oPeTaq__activeBadge",
  "addButton": "ImportChannel-module__oPeTaq__addButton",
  "betaAvatar": "ImportChannel-module__oPeTaq__betaAvatar",
  "blueYellowProgress": "ImportChannel-module__oPeTaq__blueYellowProgress",
  "columnHeader": "ImportChannel-module__oPeTaq__columnHeader",
  "connectionCell": "ImportChannel-module__oPeTaq__connectionCell",
  "container": "ImportChannel-module__oPeTaq__container",
  "deleteAction": "ImportChannel-module__oPeTaq__deleteAction",
  "deltaAvatar": "ImportChannel-module__oPeTaq__deltaAvatar",
  "dropdown": "ImportChannel-module__oPeTaq__dropdown",
  "dropdownArrow": "ImportChannel-module__oPeTaq__dropdownArrow",
  "filterApplied": "ImportChannel-module__oPeTaq__filterApplied",
  "gammaAvatar": "ImportChannel-module__oPeTaq__gammaAvatar",
  "greenProgress": "ImportChannel-module__oPeTaq__greenProgress",
  "header": "ImportChannel-module__oPeTaq__header",
  "inactiveBadge": "ImportChannel-module__oPeTaq__inactiveBadge",
  "menuButton": "ImportChannel-module__oPeTaq__menuButton",
  "nonactiveBadge": "ImportChannel-module__oPeTaq__nonactiveBadge",
  "orangeProgress": "ImportChannel-module__oPeTaq__orangeProgress",
  "progressBar": "ImportChannel-module__oPeTaq__progressBar",
  "progressBarAcmeContainer": "ImportChannel-module__oPeTaq__progressBarAcmeContainer",
  "progressBarBetaContainer": "ImportChannel-module__oPeTaq__progressBarBetaContainer",
  "progressBarDeltaContainer": "ImportChannel-module__oPeTaq__progressBarDeltaContainer",
  "progressBarGammaContainer": "ImportChannel-module__oPeTaq__progressBarGammaContainer",
  "progressCell": "ImportChannel-module__oPeTaq__progressCell",
  "progressInfo": "ImportChannel-module__oPeTaq__progressInfo",
  "progressLabel": "ImportChannel-module__oPeTaq__progressLabel",
  "progressPercentage": "ImportChannel-module__oPeTaq__progressPercentage",
  "progressValue": "ImportChannel-module__oPeTaq__progressValue",
  "redProgress": "ImportChannel-module__oPeTaq__redProgress",
  "searchContainer": "ImportChannel-module__oPeTaq__searchContainer",
  "searchIcon": "ImportChannel-module__oPeTaq__searchIcon",
  "searchInput": "ImportChannel-module__oPeTaq__searchInput",
  "showContainer": "ImportChannel-module__oPeTaq__showContainer",
  "showLabel": "ImportChannel-module__oPeTaq__showLabel",
  "statusBadge": "ImportChannel-module__oPeTaq__statusBadge",
  "statusCell": "ImportChannel-module__oPeTaq__statusCell",
  "syncCell": "ImportChannel-module__oPeTaq__syncCell",
  "table": "ImportChannel-module__oPeTaq__table",
  "tableRow": "ImportChannel-module__oPeTaq__tableRow",
  "title": "ImportChannel-module__oPeTaq__title",
  "vendorAvatar": "ImportChannel-module__oPeTaq__vendorAvatar",
  "vendorCell": "ImportChannel-module__oPeTaq__vendorCell",
  "vendorInfo": "ImportChannel-module__oPeTaq__vendorInfo",
});
}}),
"[project]/app/images/logo_amazon.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/logo_amazon.bebc4d50.png");}}),
"[project]/app/images/logo_amazon.png.mjs { IMAGE => \"[project]/app/images/logo_amazon.png (static in ecmascript)\" } [app-ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_amazon$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/logo_amazon.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_amazon$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 161,
    height: 64,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAbklEQVR42gFjAJz/ABYWFlEVFRVdGBgYZBgYGFgVFRVTFxcXWRcXF1wVFRVeABsbGmAqIxhsIRwTZCEfGmw6LhpzLiYaaRgYGGMRERFaAAICAQMfFAIWSS0BP08wAklLMAQ0GxEDEgEBAQIBAQEC7wMNukS47DIAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 3
};
}}),
"[project]/app/images/logo_google.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/logo_google.34c759c0.png");}}),
"[project]/app/images/logo_google.png.mjs { IMAGE => \"[project]/app/images/logo_google.png (static in ecmascript)\" } [app-ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_google$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/logo_google.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_google$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 141,
    height: 47,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAbklEQVR42gFjAJz/ABk+c2MULFFFJQoMIiIQBxwiGw0fChgpJRY+K1ErDAomABY3ZVckOmlkcx8nb4Q/HW9xXDVxJEl6cEZbWJKcIR6CAAwdNi4PHDQvOQwNMDgbDC05MCA7H0qFdB8xPUxFDg033YoU4v8ffKoAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 3
};
}}),
"[project]/app/images/logo_walmart.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/logo_walmart.1db54eeb.png");}}),
"[project]/app/images/logo_walmart.png.mjs { IMAGE => \"[project]/app/images/logo_walmart.png (static in ecmascript)\" } [app-ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_walmart$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/app/images/logo_walmart.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_walmart$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 215,
    height: 56,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAATUlEQVR42gFCAL3/AAArUlEAJkhFACE/QQAcNDEAHTc0ByE0N0IvAjNJNAE3AAAuWFcANGFfADFaXQArUVAANGBfByY9QUQzAzZPOAA6a4oLrqNkBRAAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 2
};
}}),
"[project]/app/export/import-from-channel/ImportChannel.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>VendorSetup)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/app/export/import-from-channel/ImportChannel.module.css [app-ssr] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_amazon$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo_amazon$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/logo_amazon.png.mjs { IMAGE => "[project]/app/images/logo_amazon.png (static in ecmascript)" } [app-ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_google$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo_google$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/logo_google.png.mjs { IMAGE => "[project]/app/images/logo_google.png (static in ecmascript)" } [app-ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_walmart$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo_walmart$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/logo_walmart.png.mjs { IMAGE => "[project]/app/images/logo_walmart.png (static in ecmascript)" } [app-ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/app/images/logo.png.mjs { IMAGE => "[project]/app/images/logo.png (static in ecmascript)" } [app-ssr] (structured image object, ecmascript)');
"use client";
;
;
;
;
;
;
;
;
;
function VendorSetup() {
    const [showActionMenu, setShowActionMenu] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const toggleActionMenu = (index)=>{
        setShowActionMenu(showActionMenu === index ? null : index);
    };
    // Sample vendor data for cleaner rendering
    const vendors = [
        {
            id: 1,
            logo: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
            //   filterApplied: "Electronics In-Stock",
            progressValue: 1500,
            progressPercent: 70,
            progressClass: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].greenProgress,
            progressBarClass: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].progressBarAcmeContainer,
            lastSync: "2025-05-12 , 8:15 PM",
            status: "Connected",
            statusClass: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].activeBadge
        },
        {
            id: 2,
            logo: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_google$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo_google$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
            //   filterApplied: "Trial Offer",
            progressValue: 1200,
            progressPercent: 65,
            progressClass: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].redProgress,
            progressBarClass: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].progressBarBetaContainer,
            lastSync: "2025-04-20 , 8:10 PM",
            status: "Setup Required",
            statusClass: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].nonactiveBadge
        },
        {
            id: 3,
            logo: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_amazon$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo_amazon$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
            //   filterApplied: "Student Pricing",
            progressValue: 200,
            progressPercent: 80,
            progressClass: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].orangeProgress,
            progressBarClass: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].progressBarGammaContainer,
            lastSync: "2025-02-12 , 10:15 PM",
            status: "Error",
            statusClass: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].inactiveBadge
        },
        {
            id: 4,
            logo: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$images$2f$logo_walmart$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$app$2f$images$2f$logo_walmart$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
            //   filterApplied: "Sectional Discount",
            progressValue: 1800,
            progressPercent: 30,
            progressClass: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].blueYellowProgress,
            progressBarClass: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].progressBarDeltaContainer,
            lastSync: "2025-01-07 , 11:15 PM",
            status: "Error",
            statusClass: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].inactiveBadge
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].container,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].header,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].title,
                    children: "Import from Channels"
                }, void 0, false, {
                    fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                    lineNumber: 73,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                lineNumber: 72,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].table,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].columnHeader,
                                    children: "Icon"
                                }, void 0, false, {
                                    fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                    lineNumber: 79,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].columnHeader,
                                    children: "Progress"
                                }, void 0, false, {
                                    fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                    lineNumber: 81,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].columnHeader,
                                    children: "Last Export"
                                }, void 0, false, {
                                    fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                    lineNumber: 82,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].columnHeader,
                                    children: "Status"
                                }, void 0, false, {
                                    fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                    lineNumber: 83,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].columnHeader
                                }, void 0, false, {
                                    fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                    lineNumber: 84,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                            lineNumber: 78,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                        lineNumber: 77,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                        children: vendors.map((vendor, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].tableRow,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].vendorCell,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].vendorInfo,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                src: vendor.logo,
                                                alt: "Vendor Logo",
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].vendorLogo,
                                                // width={0}
                                                // height={0}
                                                style: {
                                                    width: 100,
                                                    height: 30
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                lineNumber: 92,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                            lineNumber: 91,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                        lineNumber: 90,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].progressCell,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].progressInfo,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].progressLabel,
                                                        children: "Total Product Imported"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                        lineNumber: 109,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].progressValue,
                                                        children: vendor.progressValue
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                        lineNumber: 112,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                lineNumber: 108,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: vendor.progressBarClass,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].progressBar} ${vendor.progressClass}`,
                                                    style: {
                                                        width: `${vendor.progressPercent}%`
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                    lineNumber: 117,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                lineNumber: 116,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].progressPercentage,
                                                children: [
                                                    vendor.progressPercent,
                                                    "%"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                lineNumber: 122,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                        lineNumber: 107,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].syncCell,
                                        children: vendor.lastSync
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                        lineNumber: 126,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].statusCell,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].statusBadge} ${vendor.statusClass}`,
                                            children: vendor.status
                                        }, void 0, false, {
                                            fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                            lineNumber: 128,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                        lineNumber: 127,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actionColumn,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].menuButton,
                                                onClick: ()=>toggleActionMenu(index),
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    width: "20",
                                                    height: "20",
                                                    viewBox: "0 0 24 24",
                                                    fill: "currentColor",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                            cx: "12",
                                                            cy: "12",
                                                            r: "1"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                            lineNumber: 144,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                            cx: "12",
                                                            cy: "6",
                                                            r: "1"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                            lineNumber: 145,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                            cx: "12",
                                                            cy: "18",
                                                            r: "1"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                            lineNumber: 146,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                    lineNumber: 137,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                lineNumber: 133,
                                                columnNumber: 17
                                            }, this),
                                            showActionMenu === index && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actionMenu,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actionMenuItem,
                                                        children: "Edit"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                        lineNumber: 152,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actionMenuItem,
                                                        children: "Update"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                        lineNumber: 153,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actionMenuItem} ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$export$2f$import$2d$from$2d$channel$2f$ImportChannel$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].deleteAction}`,
                                                        children: "Delete"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                        lineNumber: 154,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                                lineNumber: 151,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                        lineNumber: 132,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, vendor.id, true, {
                                fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                                lineNumber: 89,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                        lineNumber: 87,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
                lineNumber: 76,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/export/import-from-channel/ImportChannel.js",
        lineNumber: 71,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=app_af631ce3._.js.map