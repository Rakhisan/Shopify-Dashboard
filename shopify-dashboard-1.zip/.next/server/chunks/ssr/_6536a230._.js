module.exports = {

"[project]/.next-internal/server/app/catalogue/catalog-filter/page/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/app/layout.js [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.js [app-rsc] (ecmascript)"));
}}),
"[project]/app/catalogue/catalog-filter/CatalogueFilter.module.css [app-rsc] (css module)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v({
  "actionsColumn": "CatalogueFilter-module__nkpL0q__actionsColumn",
  "checkboxColumn": "CatalogueFilter-module__nkpL0q__checkboxColumn",
  "container": "CatalogueFilter-module__nkpL0q__container",
  "countColumn": "CatalogueFilter-module__nkpL0q__countColumn",
  "createdByColumn": "CatalogueFilter-module__nkpL0q__createdByColumn",
  "criteriaColumn": "CatalogueFilter-module__nkpL0q__criteriaColumn",
  "filterButton": "CatalogueFilter-module__nkpL0q__filterButton",
  "filterOptions": "CatalogueFilter-module__nkpL0q__filterOptions",
  "filtersTable": "CatalogueFilter-module__nkpL0q__filtersTable",
  "header": "CatalogueFilter-module__nkpL0q__header",
  "idColumn": "CatalogueFilter-module__nkpL0q__idColumn",
  "inputWrapper": "CatalogueFilter-module__nkpL0q__inputWrapper",
  "menuButton": "CatalogueFilter-module__nkpL0q__menuButton",
  "menuDots": "CatalogueFilter-module__nkpL0q__menuDots",
  "menuDropdown": "CatalogueFilter-module__nkpL0q__menuDropdown",
  "nameColumn": "CatalogueFilter-module__nkpL0q__nameColumn",
  "pagination": "CatalogueFilter-module__nkpL0q__pagination",
  "paginationButton": "CatalogueFilter-module__nkpL0q__paginationButton",
  "searchContainer": "CatalogueFilter-module__nkpL0q__searchContainer",
  "searchIcon": "CatalogueFilter-module__nkpL0q__searchIcon",
  "searchInput": "CatalogueFilter-module__nkpL0q__searchInput",
  "select": "CatalogueFilter-module__nkpL0q__select",
  "selectContainer": "CatalogueFilter-module__nkpL0q__selectContainer",
  "selectedRow": "CatalogueFilter-module__nkpL0q__selectedRow",
  "showOptions": "CatalogueFilter-module__nkpL0q__showOptions",
  "showSelect": "CatalogueFilter-module__nkpL0q__showSelect",
  "tableContainer": "CatalogueFilter-module__nkpL0q__tableContainer",
  "title": "CatalogueFilter-module__nkpL0q__title",
});
}}),
"[project]/app/catalogue/catalog-filter/CatalogueFilter.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// components/CatalogueFilter.js
__turbopack_context__.s({
    "default": (()=>CatalogueFilter)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/app/catalogue/catalog-filter/CatalogueFilter.module.css [app-rsc] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fa/index.mjs [app-rsc] (ecmascript)");
;
;
;
;
;
function CatalogueFilter() {
    const [filters, setFilters] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])([
        {
            id: '#301012',
            name: 'Electronics In Stock',
            criteria: 'Smart Devices & Innovation',
            createdBy: 'Alex Johnson',
            productCount: '1900',
            selected: false
        },
        {
            id: '#301011',
            name: 'Home Appliances Available',
            criteria: 'Tech/Next',
            createdBy: 'Emily Davis',
            productCount: '1600',
            selected: false
        },
        {
            id: '#301002',
            name: 'Gadgets On Sale',
            criteria: 'Tech/Next',
            createdBy: 'Michael Brown',
            productCount: '1700',
            selected: false
        },
        {
            id: '#301001',
            name: 'Latest Smartphones',
            criteria: 'Tech/Next',
            createdBy: 'Sarah Wilson',
            productCount: '1800',
            selected: false
        },
        {
            id: '#301000',
            name: 'Laptops and Notebooks',
            criteria: 'Tech/Next',
            createdBy: 'David Lee',
            productCount: '1900',
            selected: false
        },
        {
            id: '#301800',
            name: 'Wearable Tech Items',
            criteria: 'Tech/Next',
            createdBy: 'Jessica Taylor',
            productCount: '2000',
            selected: false
        },
        {
            id: '#301701',
            name: 'Smart Home Devices',
            criteria: 'Tech/Next',
            createdBy: 'Daniel Martinez',
            productCount: '2100',
            selected: false
        },
        {
            id: '#301600',
            name: 'Gaming Consoles',
            criteria: 'Tech/Next',
            createdBy: 'Laura Anderson',
            productCount: '2200',
            selected: false
        },
        {
            id: '#301500',
            name: 'Audio Equipment',
            criteria: 'Tech/Next',
            createdBy: 'James Thomas',
            productCount: '2300',
            selected: false
        },
        {
            id: '#301400',
            name: 'Computer Accessories',
            criteria: 'Tech/Next',
            createdBy: 'Sophia White',
            productCount: '2400',
            selected: false
        }
    ]);
    const [activeMenu, setActiveMenu] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(1);
    const [itemsPerPage, setItemsPerPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["useState"])(10);
    const handleCheckboxChange = (id)=>{
        setFilters(filters.map((filter)=>filter.id === id ? {
                ...filter,
                selected: !filter.selected
            } : filter));
    };
    const toggleMenu = (id)=>{
        if (activeMenu === id) {
            setActiveMenu(null);
        } else {
            setActiveMenu(id);
        }
    };
    const handleMenuAction = (action, id)=>{
        console.log(`${action} action for filter ${id}`);
        setActiveMenu(null);
    };
    const handlePageChange = (page)=>{
        setCurrentPage(page);
    };
    // Calculate pagination
    const totalPages = Math.ceil(filters.length / itemsPerPage);
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = filters.slice(indexOfFirstItem, indexOfLastItem);
    // Import font in the head section if using Next.js pages directory
    const addPublicSansFont = ()=>{
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(void 0, {
            id: "e9c065ac83c5329a",
            children: '@import "https://fonts.googleapis.com/css2?family=Public+Sans:wght@300;400;500;600;700&display=swap";'
        }, void 0, false, void 0, this);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].container,
        children: [
            addPublicSansFont(),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].header,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].title,
                        children: "Catalogue Filters"
                    }, void 0, false, {
                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                        lineNumber: 65,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].searchContainer,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].inputWrapper,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["FaSearch"], {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].searchIcon
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 68,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        placeholder: "Search Catalog",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].searchInput
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 69,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                lineNumber: 67,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].selectContainer,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].select,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            children: "All Catalog"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 78,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            children: "Electronics"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 79,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            children: "Home Appliances"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 80,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            children: "Gadgets"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 81,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            children: "Smartphones"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 82,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                    lineNumber: 77,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                lineNumber: 76,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].filterOptions,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].filterButton,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "Filters"
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 88,
                                            columnNumber: 29
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 87,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].showOptions,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "Show"
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                lineNumber: 91,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].showSelect,
                                                value: itemsPerPage,
                                                onChange: (e)=>setItemsPerPage(Number(e.target.value)),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: 5,
                                                        children: "5"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                        lineNumber: 93,
                                                        columnNumber: 33
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: 10,
                                                        children: "10"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                        lineNumber: 94,
                                                        columnNumber: 33
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: 20,
                                                        children: "20"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                        lineNumber: 95,
                                                        columnNumber: 33
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: 50,
                                                        children: "50"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                        lineNumber: 96,
                                                        columnNumber: 33
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                lineNumber: 92,
                                                columnNumber: 29
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 90,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                lineNumber: 86,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                        lineNumber: 66,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                lineNumber: 64,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].tableContainer,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].filtersTable,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].checkboxColumn,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "checkbox",
                                            onChange: ()=>{
                                                const allSelected = filters.every((filter)=>filter.selected);
                                                setFilters(filters.map((filter)=>({
                                                        ...filter,
                                                        selected: !allSelected
                                                    })));
                                            },
                                            checked: filters.length > 0 && filters.every((filter)=>filter.selected)
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 109,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 108,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].idColumn,
                                        children: "ID"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 118,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].nameColumn,
                                        children: "Filter Name"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 119,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].criteriaColumn,
                                        children: "Criteria"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 120,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].createdByColumn,
                                        children: "Created By"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 121,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].countColumn,
                                        children: "Product Count"
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 122,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].actionsColumn
                                    }, void 0, false, {
                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                        lineNumber: 123,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                lineNumber: 107,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                            lineNumber: 106,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                            children: currentItems.map((filter)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    className: filter.selected ? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].selectedRow : '',
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].checkboxColumn,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "checkbox",
                                                checked: filter.selected,
                                                onChange: ()=>handleCheckboxChange(filter.id)
                                            }, void 0, false, {
                                                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                lineNumber: 130,
                                                columnNumber: 37
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 129,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].idColumn,
                                            children: filter.id
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 136,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].nameColumn,
                                            children: filter.name
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 137,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].criteriaColumn,
                                            children: filter.criteria
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 138,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].createdByColumn,
                                            children: filter.createdBy
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 139,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].countColumn,
                                            children: filter.productCount
                                        }, void 0, false, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 140,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].actionsColumn,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].menuButton,
                                                    onClick: ()=>toggleMenu(filter.id),
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].menuDots,
                                                        children: "⋮"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                        lineNumber: 143,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                    lineNumber: 142,
                                                    columnNumber: 37
                                                }, this),
                                                activeMenu === filter.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].menuDropdown,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>handleMenuAction('edit', filter.id),
                                                            children: "Edit"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                            lineNumber: 147,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>handleMenuAction('update', filter.id),
                                                            children: "Update"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                            lineNumber: 148,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>handleMenuAction('delete', filter.id),
                                                            children: "Delete"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                            lineNumber: 149,
                                                            columnNumber: 45
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                                    lineNumber: 146,
                                                    columnNumber: 41
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                            lineNumber: 141,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, filter.id, true, {
                                    fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                                    lineNumber: 128,
                                    columnNumber: 29
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                            lineNumber: 126,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                    lineNumber: 105,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                lineNumber: 104,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].pagination,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].paginationButton,
                        onClick: ()=>handlePageChange(currentPage - 1),
                        disabled: currentPage === 1,
                        "aria-label": "Previous page",
                        children: "<"
                    }, void 0, false, {
                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                        lineNumber: 160,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].paginationButton,
                        onClick: ()=>handlePageChange(currentPage + 1),
                        disabled: currentPage === totalPages,
                        "aria-label": "Next page",
                        children: ">"
                    }, void 0, false, {
                        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                        lineNumber: 168,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
                lineNumber: 159,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/catalogue/catalog-filter/CatalogueFilter.js",
        lineNumber: 62,
        columnNumber: 9
    }, this);
}
}}),
"[project]/app/catalogue/catalog-filter/page.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>CatalogFilterPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/catalogue/catalog-filter/CatalogueFilter.js [app-rsc] (ecmascript)");
;
;
function CatalogFilterPage() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$catalogue$2f$catalog$2d$filter$2f$CatalogueFilter$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/app/catalogue/catalog-filter/page.js",
        lineNumber: 4,
        columnNumber: 10
    }, this);
}
}}),
"[project]/app/catalogue/catalog-filter/page.js [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/app/catalogue/catalog-filter/page.js [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=_6536a230._.js.map