import PriceProfile from "@/app/price/profile/Price";

export default function PriceProfilePage() {
  return <PriceProfile />;
  //   return <></>;
}
