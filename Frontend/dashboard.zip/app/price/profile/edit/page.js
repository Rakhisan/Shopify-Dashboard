import EditProfile from "@/app/price/profile/edit/Editprofile";

// import VendorSetup from "../../../components/catalogue/vendorsetup";

export default function EditProfilePage() {
  return <EditProfile />;
}
