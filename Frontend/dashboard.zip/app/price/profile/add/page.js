import AddProfile from "@/app/price/profile/add/AddProfile";

// import VendorSetup from "../../../components/catalogue/vendorsetup";

export default function AddProfilePage() {
  return <AddProfile />;
}
