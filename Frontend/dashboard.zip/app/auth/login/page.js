import Login from "@/app/auth/login/Login"; // ✅ Correct if file is Login.js

export default function LoginPage() {
  return <Login />;
}
