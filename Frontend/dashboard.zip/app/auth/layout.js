export default function SignUpLayout({ children }) {
  return <>{children}</>; // Or wrap in a div/main if needed
}
