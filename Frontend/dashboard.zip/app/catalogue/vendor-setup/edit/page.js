import EditVendor from "@/app/catalogue/vendor-setup/edit/EditVendor";

export default function EditVendorPage() {
  return <EditVendor />;
}
