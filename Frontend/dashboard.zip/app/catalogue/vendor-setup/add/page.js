import AddVendor from "@/app/catalogue/vendor-setup/add/AddVendor";

export default function AddVendorPage() {
  return <AddVendor />;
}
