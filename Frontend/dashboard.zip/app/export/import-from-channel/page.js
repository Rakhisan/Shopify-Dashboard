import ImportChannel from "@/app/export/import-from-channel/ImportChannel";

export default function ImportChannelPage() {
  return <ImportChannel />;
}
