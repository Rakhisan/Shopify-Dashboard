import EditExport from "@/app/export/export-to-channel/edit/EditExport";

export default function EditExportPage() {
  return <EditExport />;
}
