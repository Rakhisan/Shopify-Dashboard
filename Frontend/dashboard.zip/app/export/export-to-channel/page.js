import ExportChannel from "@/app/export/export-to-channel/ExportChannel";

export default function ExportChannelPage() {
  return <ExportChannel />;
}
