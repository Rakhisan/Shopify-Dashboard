import EditUser from "@/app/admin/user/edit/EditUser";
export default function EditUserPage() {
  return <EditUser />;
}
