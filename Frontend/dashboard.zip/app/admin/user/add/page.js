import AddUser from "@/app/admin/user/add/AddUser";
export default function AddUserPage() {
  return <AddUser />;
}
