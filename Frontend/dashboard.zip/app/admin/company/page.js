import CompanyProfile from "@/app/admin/company/CompanyProfile";

// import VendorSetup from "../../../components/catalogue/vendorsetup";

export default function CompanyProfilePage() {
  return <CompanyProfile />;
}
