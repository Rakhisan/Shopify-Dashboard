import Setting from "@/app/settings/Setting";

export default function SettingPage() {
    return <Setting />;
}
