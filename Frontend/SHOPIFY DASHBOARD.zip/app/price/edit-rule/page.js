
import EditRule from "@/app/price/edit-rule/EditRule";

export default function EditRulePage() {
    return <EditRule />;
}
