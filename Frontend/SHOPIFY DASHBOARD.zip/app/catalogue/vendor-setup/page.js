import VendorSetupTable from "@/app/catalogue/vendor-setup/VendorSetupTable";

export default function VendorSetupPage() {
  return <VendorSetupTable />;
}
