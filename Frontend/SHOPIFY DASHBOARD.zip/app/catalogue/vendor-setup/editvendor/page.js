import EditVendor from "@/app/catalogue/vendor-setup/editvendor/EditVendor";

export default function EditVendorPage() {
    return <EditVendor />;
}
