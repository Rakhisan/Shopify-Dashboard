import AddVendor from "@/app/catalogue/vendor-setup/addvendor/AddVendor";

export default function AddVendorPage() {
    return <AddVendor />;
}
