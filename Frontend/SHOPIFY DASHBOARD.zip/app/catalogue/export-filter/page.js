import ExportFilter from "@/app/catalogue/export-filter/ExportFilter";

export default function ExportFilterPage() {
  return <ExportFilter />;
}
