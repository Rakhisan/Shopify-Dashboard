import YourCatalog from "@/app/catalogue/your-catalog/YourCatalog";

// import VendorSetup from "../../../components/catalogue/vendorsetup";

export default function YourCatalogPage() {
  return <YourCatalog />;
}
