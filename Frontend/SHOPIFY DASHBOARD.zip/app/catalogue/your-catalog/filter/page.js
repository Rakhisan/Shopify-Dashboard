import Filter from "@/app/catalogue/your-catalog/filter/Filter";

export default function FilterPage() {
  return <Filter />;
}
