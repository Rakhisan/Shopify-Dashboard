import EditExport from "@/app/export/export-to-channel/edit-export/EditExport";

export default function EditExportPage() {
  return <EditExport />;
}
