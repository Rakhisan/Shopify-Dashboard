import ExportImportDashboard from "@/app/export/export-dashboard/ExportImportDashboard";

// import VendorSetup from "../../../components/catalogue/vendorsetup";

export default function UserTablePage() {
  return <ExportImportDashboard />;
}
