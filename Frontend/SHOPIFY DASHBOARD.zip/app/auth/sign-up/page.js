import SignUp from "@/app/auth/sign-up/Signup";

export default function SignUpPage() {
  return <SignUp />;
  //   return <></>;
}
