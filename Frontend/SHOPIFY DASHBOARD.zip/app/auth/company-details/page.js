import CompanyDetails from "@/app/auth/company-details/CompanyDetails";

// import VendorSetup from "../../../components/catalogue/vendorsetup";

export default function CompanyDetailPage() {
  return <CompanyDetails />;
}
