import Email from "@/app/auth/email/Email";

export default function EmailPage() {
  return <Email />;
  //   return <></>;
}
