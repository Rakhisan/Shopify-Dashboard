import EditUser from "@/app/admin/user/edituser/EditUser";
export default function EditUserPage() {
  return <EditUser />;
}
