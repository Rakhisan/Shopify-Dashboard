import AddUser from "@/app/admin/user/adduser/AddUser";
export default function AddUserPage() {
    return <AddUser />;

}