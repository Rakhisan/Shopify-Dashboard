"use client";
import { useState } from "react";
import styles from "./VentorDashboard.module.css";

export default function Vendor() {
  const [vendors, setVendors] = useState([
    {
      id: "A",
      product: "1250",
      stock: "98%",
      sync: "7x/week",
      active: "7x/week",
      time: "16 April 2:00 PM",
    },
    {
      id: "B",
      product: "1680",
      stock: "75%",
      sync: "5x/week",
      active: "5x/week",
      time: "20 April 4:00 PM",
    },
    {
      id: "C",
      product: "1800",
      stock: "28%",
      sync: "9x/week",
      active: "9x/week",
      time: "12 April 5:00 PM",
    },
    {
      id: "D",
      product: "1255",
      stock: "78%",
      sync: "5x/week",
      active: "5x/week",
      time: "11 April 6:00 PM",
    },
    {
      id: "E",
      product: "1000",
      stock: "50%",
      sync: "4x/week",
      active: "4x/week",
      time: "20 April 7:00 PM",
    },
    {
      id: "F",
      product: "878",
      stock: "90%",
      sync: "3x/week",
      active: "3x/week",
      time: "18 April 8:00 PM",
    },
  ]);

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1 className={styles.title}>Vendors</h1>
        <div>
          <button className={styles.seeMoreBtn}>See More</button>
        </div>
      </div>

      {/* Desktop view */}
      <div className={styles.tableWrapper}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>
                <div className={styles.headerCell}>Vendor</div>
              </th>
              <th>
                <div className={styles.headerCell}>Product Count</div>
              </th>
              <th>
                <div className={styles.headerCell}>Stock Availability</div>
              </th>
              <th>
                <div className={styles.headerCell}>Sync Frequency</div>
              </th>
              <th>
                <div className={styles.headerCell}>Active Status</div>
              </th>
              <th>
                <div className={styles.headerCell}>Time Stamps</div>
              </th>
            </tr>
          </thead>
          <tbody>
            {vendors.map((vendor, index) => (
              <tr
                key={index}
                className={index % 2 === 0 ? styles.rowEven : styles.rowOdd}
              >
                <td>Vendor {vendor.id}</td>
                <td>{vendor.product}</td>
                <td>{vendor.stock}</td>
                <td>{vendor.sync}</td>
                <td>{vendor.active}</td>
                <td>{vendor.time}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile view */}
      <div className={styles.mobileView}>
        {vendors.map((vendor, index) => (
          <div key={index} className={styles.mobileCard}>
            <div className={styles.mobileCardHeader}>Vendor {vendor.id}</div>
            <div className={styles.mobileCardBody}>
              <div className={styles.mobileCardRow}>
                <span className={styles.mobileCardLabel}>Product Count:</span>
                <span className={styles.mobileCardValue}>{vendor.product}</span>
              </div>
              <div className={styles.mobileCardRow}>
                <span className={styles.mobileCardLabel}>
                  Stock Availability:
                </span>
                <span className={styles.mobileCardValue}>{vendor.stock}</span>
              </div>
              <div className={styles.mobileCardRow}>
                <span className={styles.mobileCardLabel}>Sync Frequency:</span>
                <span className={styles.mobileCardValue}>{vendor.sync}</span>
              </div>
              <div className={styles.mobileCardRow}>
                <span className={styles.mobileCardLabel}>Active Status:</span>
                <span className={styles.mobileCardValue}>{vendor.active}</span>
              </div>
              <div className={styles.mobileCardRow}>
                <span className={styles.mobileCardLabel}>Time Stamps:</span>
                <span className={styles.mobileCardValue}>{vendor.time}</span>
              </div>
            </div>
          </div>
        ))}

        {/* Mobile See More button at the bottom */}
        <div className={styles.mobileSeeMoreContainer}>
          <button className={styles.seeMoreBtn}>See More</button>
        </div>
      </div>
    </div>
  );
}
