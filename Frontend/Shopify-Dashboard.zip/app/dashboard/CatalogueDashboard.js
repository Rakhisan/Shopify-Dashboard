"use client";
import { useState } from "react";
import styles from "./CatalogueDashboard.module.css";
import product1 from "../images/Product1.png";
import product2 from "../images/Product2.png";
import product3 from "../images/Product3.png";
import product4 from "../images/Product4.png";
import Image from "next/image";

export default function Catalogue() {
  const [catalogueItems] = useState([
    {
      id: 1,
      name: "Sony Headphone",
      category: "Electronics",
      activeCategory: "Active Catalogues",
      activeCount: 400,
      totalProducts: "Total Products",
      totalCount: 1500,
      image: product1,
      status: "Status",
      updated: "Updated 3 hr ago",
    },
    {
      id: 2,
      name: "Luxury Home",
      category: "Home & Kitchen",
      activeCategory: "Active Catalogues",
      activeCount: 300,
      totalProducts: "Total Products",
      totalCount: 1200,
      image: product2,
      status: "Status",
      updated: "Updated 2.5 hrs ago",
    },
    {
      id: 3,
      name: "Outfits",
      category: "Fashion",
      activeCategory: "Active Catalogues",
      activeCount: 500,
      totalProducts: "Total Products",
      totalCount: 2000,
      image: product3,
      status: "Status",
      updated: "Updated 4 hrs ago",
    },
    {
      id: 4,
      name: "Moisturizer",
      category: "Beauty",
      activeCategory: "Active Catalogues",
      activeCount: 200,
      totalProducts: "Total Products",
      totalCount: 800,
      image: product4,
      status: "Status",
      updated: "Updated 1 hr ago",
    },
  ]);

  return (
    <div className={styles.catalogueContainer}>
      {/* Catalogue Header */}
      <div className={styles.catalogueHeader}>
        <h2>Catalogue</h2>
      </div>

      {/* Catalogue Items Grid */}
      <div className={styles.catalogueGrid}>
        {catalogueItems.map((item) => (
          <div key={item.id} className={styles.catalogueCard}>
            {/* Item Image */}
            <div className={styles.imageContainer}>
              <Image src={item.image} alt={item.name} />
            </div>

            {/* Item Details */}
            <div className={styles.cardContent}>
              <h3>{item.name}</h3>
              <p className={styles.category}>{item.category}</p>

              <div className={styles.statsVertical}>
                <div className={styles.statRow}>
                  <p className={styles.statLabel}>{item.activeCategory}</p>
                  <div className={styles.priceTag}>
                    <span>{item.activeCount}</span>
                  </div>
                </div>
                <div className={styles.statRow}>
                  <p className={styles.statLabel}>{item.totalProducts}</p>
                  <div className={styles.priceTag}>
                    <span>{item.totalCount}</span>
                  </div>
                </div>
                <div className={styles.statRow}>
                  <p className={styles.statLabel}>{item.status}</p>
                  <p className={styles.updatedTime}>{item.updated}</p>
                </div>
              </div>

              {/* See more button */}
              <button className={styles.seeMoreBtn}>See more</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
