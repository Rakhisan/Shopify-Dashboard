import Password from "@/app/auth/password/Password";

export default function PasswordPage() {
  return <Password />;
  //   return <></>;
}
