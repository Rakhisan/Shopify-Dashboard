import UserTable from "@/app/admin/user/UserTable";

// import VendorSetup from "../../../components/catalogue/vendorsetup";

export default function UserTablePage() {
  return <UserTable />;
}
