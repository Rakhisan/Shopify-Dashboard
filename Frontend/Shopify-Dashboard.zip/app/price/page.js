import Price from "@/app/price/Price";

export default function PriceProfile() {
  return <Price />;
  //   return <></>;
}
