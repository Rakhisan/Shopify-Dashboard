import PriceRule from "@/app/price/price-rule/PriceRule";

export default function PriceRulePage() {
  return <PriceRule />;
}
