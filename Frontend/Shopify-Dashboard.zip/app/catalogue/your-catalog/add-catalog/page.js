import AddCatalog from "@/app/catalogue/your-catalog/add-catalog/AddCatalog";

// import VendorSetup from "../../../components/catalogue/vendorsetup";

export default function AddCatalogPage() {
    return <AddCatalog />;
}
