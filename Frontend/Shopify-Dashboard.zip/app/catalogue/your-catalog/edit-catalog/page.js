
import EditCatalog from "@/app/catalogue/your-catalog/edit-catalog/EditCatalog";

// import VendorSetup from "../../../components/catalogue/vendorsetup";

export default function YourCataloguePage() {
    return <EditCatalog />;
}
