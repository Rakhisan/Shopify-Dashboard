"use client";
import { use, useState } from "react";
import Image from "next/image";
import styles from "./YourCatalogue.module.css";
// import Handmadepouch from './images/Handmadepouch.png';
import h1 from "../../images/Handmade Pouch.png";
import Smartwatch from "../../images/Watch.png";
//import Smartwatch from "../../images/smartwatch-e1.png";
import Headphone from "../../images/Headphone.png";
import Iphone from "../../images/iphone.png";
import Puma from "../../images/Puma Shoes.png";
import Imac from "../../images/Imac.png";
import LegoCar from "../../images/Lego Car.png";
import Skincare from "../../images/SkinCare.png";
import NikeShoes from "../../images/Nike Shoes.png";
import { AiOutlineCaretDown } from "react-icons/ai";
import { useRouter } from "next/navigation";

const catalogData = [
  {
    id: "#302012",
    name: "Handmade Pouch",
    vendor: "Acme Corp",
    category: "Electronics",
    stock: "50 units",
    status: "In-Stock",
    image: h1,
  },

  {
    id: "#302011",
    name: "Smartwatch E2",
    vendor: "Tech Innovations",
    category: "Home Appliances",
    stock: "75 units",
    status: "Low Stock",
    image: Smartwatch,
  },
  {
    id: "#302002",
    name: "Smartwatch E1",
    vendor: "Global Solutions",
    category: "Furniture",
    stock: "100 units",
    status: "Out-of-Stock",
    image: Smartwatch,
  },
  {
    id: "#301901",
    name: "Headphone G1 Pro",
    vendor: "Eco Enterprises",
    category: "Toys",
    stock: "Weekly",
    status: "Out-of-Stock",
    image: Headphone,
  },
  {
    id: "#301900",
    name: "Iphone X",
    vendor: "Smart Devices Inc.",
    category: "Books",
    stock: "150 units",
    status: "Low Stock",
    image: Iphone,
  },
  {
    id: "#301800",
    name: "Puma Shoes",
    vendor: "NextGen Technologies",
    category: "Clothing",
    stock: "200 units",
    status: "Low Stock",
    image: Puma,
  },
  {
    id: "#301701",
    name: "Imac 2021",
    vendor: "Cloud Services Ltd.",
    category: "Sports Equipment",
    stock: "250 units",
    status: "In-Stock",
    image: Imac,
  },
  {
    id: "#301600",

    name: "Nike Shoes",
    vendor: "Digital Ventures",
    category: "Beauty Products",
    stock: "300 units",
    status: "Out-of-Stock",
    image: NikeShoes,
  },
  {
    id: "#301500",
    name: "Lego Car",
    vendor: "Future Dynamics",
    category: "Automotive Accessories",
    stock: "350 units",
    status: "Out-of-Stock",
    image: LegoCar,
  },
  {
    id: "#301400",
    name: "Skincare Alia 1",
    vendor: "Innovatech Solutions",
    category: "Gardening Tools",
    stock: "400 units",
    status: "In-Stock",
    image: Skincare,
  },
];

const statusColor = {
  "In-Stock": styles.inStock,
  "Low Stock": styles.lowStock,
  "Out-of-Stock": styles.outStock,
};

export default function Catalog() {
  const router = useRouter();

  const [showActionMenu, setShowActionMenu] = useState(null);
  const [showPageSizeDropdown, setShowPageSizeDropdown] = useState(false);
  const [selectedPageSize, setSelectedPageSize] = useState(10);

  const pageSizeOptions = [10, 20, 50];

  const handleAddUser = () => {
    router.push("/catalogue/your-catalog/add-catalog");
  };

  const handleEditCatalog = () => {
    router.push("/catalogue/your-catalog/edit-catalog");
  };

  const toggleActionMenu = (index) => {
    setShowActionMenu(showActionMenu === index ? null : index);
  };

  const togglePageSizeDropdown = () => {
    setShowPageSizeDropdown(!showPageSizeDropdown);
  };

  const handlePageSizeSelect = (size) => {
    setSelectedPageSize(size);
    setShowPageSizeDropdown(false);
  };

  return (
    <div className={styles.container}>
      <div className={styles.headerRow}>
        <h2 className={styles.title}>Your Catalogue</h2>
        <div className={styles.actions}>
          <div className={styles.searchWrapper}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className={styles.searchIcon}
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M21 21l-4.35-4.35m0 0A7.5 7.5 0 1110.5 3a7.5 7.5 0 016.15 13.65z"
              />
            </svg>
            <input
              type="text"
              placeholder="Search Catalog"
              className={styles.input}
            />
          </div>

          <button className={styles.button} onClick={handleAddUser}>
            <span className={styles.plusIcon}>+</span> Catalogue
          </button>
        </div>
      </div>

      <div className={styles.tableContainer}>
        <table className={styles.table}>
          <thead>
            <tr className={styles.tableHeaderRow}>
              <th>
                <input type="checkbox" />
              </th>
              <th>ID</th>
              <th className={styles.catalogueNameHeader}>
                Catalogue Name
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 18 18"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M4.81 6.75h8.38c.15 0 .3.04.42.13.12.08.22.2.28.34.06.13.08.28.05.42-.03.15-.1.28-.2.39L9.53 12.22c-.14.14-.33.22-.53.22s-.39-.08-.53-.22L4.28 8.03c-.1-.1-.17-.24-.2-.39a.75.75 0 01.47-.88c.12-.09.27-.13.43-.13Z"
                    fill="#8E95A6"
                  />
                </svg>
              </th>
              <th>Vendor</th>
              <th>Category</th>
              <th>Stock</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {catalogData.map((item, index) => (
              <tr key={index}>
                <td>
                  <input type="checkbox" />
                </td>
                <td className={styles.nameId}>{item.id}</td>
                <td className={styles.nameCell}>
                  <Image
                    src={item.image}
                    alt={item.name}
                    width={30}
                    height={30}
                  />
                  <span className={styles.nameText}> {item.name}</span>
                </td>
                <td>{item.vendor}</td>
                <td>{item.category}</td>
                <td>{item.stock}</td>
                <td>
                  <span
                    className={`${styles.statusBadge} ${
                      statusColor[item.status]
                    }`}
                  >
                    {item.status}
                  </span>
                </td>
                <td className={styles.actionColumn}>
                  <button
                    className={styles.menuButton}
                    onClick={() => toggleActionMenu(index)}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="currentColor"
                    >
                      <circle cx="12" cy="12" r="1" />
                      <circle cx="12" cy="6" r="1" />
                      <circle cx="12" cy="18" r="1" />
                    </svg>
                  </button>
                  {showActionMenu === index && (
                    <div className={styles.actionMenu}>
                      <div
                        className={styles.actionMenuItem}
                        onClick={handleEditCatalog}
                      >
                        Edit
                      </div>
                      <div className={styles.actionMenuItem}>Update</div>
                      <div
                        className={`${styles.actionMenuItem} ${styles.deleteAction}`}
                      >
                        Delete
                      </div>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className={styles.pagination}>
          <div className={styles.paginationButtons}>
            <button className={styles.paginationButton}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polyline points="15 18 9 12 15 6" />
              </svg>
            </button>
            <button className={styles.paginationButton}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polyline points="9 18 15 12 9 6" />
              </svg>
            </button>
          </div>
          <div className={styles.paginationInfo}>
            <span>Show</span>
            <div className={styles.customDropdown}>
              <button
                className={styles.dropdownButton}
                onClick={togglePageSizeDropdown}
              >
                {selectedPageSize}
                <AiOutlineCaretDown
                  className={`${styles.dropdownIcon} ${
                    showPageSizeDropdown ? styles.rotated : ""
                  }`}
                />
              </button>

              {showPageSizeDropdown && (
                <div className={styles.dropdownMenu}>
                  {pageSizeOptions.map((option) => (
                    <div
                      key={option}
                      className={`${styles.dropdownItem} ${
                        selectedPageSize === option ? styles.selected : ""
                      }`}
                      onClick={() => handlePageSizeSelect(option)}
                    >
                      {option}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
