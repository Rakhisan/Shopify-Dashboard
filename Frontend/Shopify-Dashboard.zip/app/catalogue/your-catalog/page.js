import YourCatalogue from "@/app/catalogue/your-catalog/YourCatalogue";

// import VendorSetup from "../../../components/catalogue/vendorsetup";

export default function YourCataloguePage() {
  return <YourCatalogue />;
}
