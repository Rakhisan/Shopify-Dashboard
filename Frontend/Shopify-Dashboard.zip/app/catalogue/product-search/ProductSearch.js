// components/CatalogueFilter.js

"use client";
import styles from "./ProductSearch.module.css";
import { Plus, Search, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";
import { MdTune } from "react-icons/md";
import { useRouter } from "next/navigation";
import { AiOutlineCaretDown } from "react-icons/ai";

export default function CatalogueFilter() {
  const router = useRouter();

  const [filters, setFilters] = useState([
    {
      id: "#902012",
      productName: "Handmade Pouch",
      catalogueName: "UrbanStyle Apparel",
      sku: "WID-123",
      vendor: "Acme Corp",
      category: "Electronics",
      price: "$99.99",
      stock: "50 units",
      status: "In-Stock",
      selected: false,
      icon: "👜",
    },
    {
      id: "#302011",
      productName: "Smartwatch E2",
      catalogueName: "Tech Essentials Hub",
      sku: "WID-789",
      vendor: "Tech Innovations",
      category: "Home Appliances",
      price: "$149.99",
      stock: "75 units",
      status: "Low Stock",
      selected: false,
      icon: "⌚",
    },
    {
      id: "#302002",
      productName: "Smartwatch E1",
      catalogueName: "Home Haven Decor",
      sku: "WID-112",
      vendor: "Global Solutions",
      category: "Furniture",
      price: "$199.99",
      stock: "100 units",
      status: "Out-of-Stock",
      selected: false,
      icon: "⌚",
    },
    {
      id: "#301901",
      productName: "Headphone G1 Pro",
      catalogueName: "EcoLife Products",
      sku: "WID-415",
      vendor: "Eco Enterprises",
      category: "Toys",
      price: "$249.99",
      stock: "Weekly",
      status: "Out-of-Stock",
      selected: false,
      icon: "🎧",
    },
    {
      id: "#301900",
      productName: "Iphone X",
      catalogueName: "Fitness Fuel Gear",
      sku: "WID-718",
      vendor: "Smart Devices Inc.",
      category: "Books",
      price: "$299.99",
      stock: "150 units",
      status: "Low Stock",
      selected: false,
      icon: "📱",
    },
    {
      id: "#301800",
      productName: "Puma Shoes",
      catalogueName: "Modern Kids Boutique",
      sku: "WID-456",
      vendor: "NextGen Technologies",
      category: "Clothing",
      price: "$349.99",
      stock: "200 units",
      status: "Low Stock",
      selected: false,
      icon: "👟",
    },
    {
      id: "#301701",
      productName: "iMac 2021",
      catalogueName: "PetPal Supplies",
      sku: "WID-101",
      vendor: "Cloud Services Ltd.",
      category: "Sports Equipment",
      price: "$399.99",
      stock: "250 units",
      status: "In-Stock",
      selected: false,
      icon: "💻",
    },
    {
      id: "#301600",
      productName: "Nike Shoes",
      catalogueName: "Gourmet Pantry Picks",
      sku: "WID-131",
      vendor: "Digital Ventures",
      category: "Beauty Products",
      price: "$449.99",
      stock: "300 units",
      status: "Out-of-Stock",
      selected: false,
      icon: "👟",
    },
    {
      id: "#301500",
      productName: "Lego Car",
      catalogueName: "Gadget Garage",
      sku: "WID-161",
      vendor: "Future Dynamics",
      category: "Automotive Accessories",
      price: "$499.99",
      stock: "350 units",
      status: "Out-of-Stock",
      selected: false,
      icon: "🧸",
    },
    {
      id: "#301400",
      productName: "Skincare Alta 1",
      catalogueName: "Luxury Skincare Vault",
      sku: "WID-192",
      vendor: "Innovatech Solutions",
      category: "Gardening Tools",
      price: "$549.99",
      stock: "400 units",
      status: "In-Stock",
      selected: false,
      icon: "🧴",
    },
  ]);

  const statusColor = {
    "In-Stock": styles.instock,
    "Low Stock": styles.lowstock,
    "Out-of-Stock": styles.outofstock,
  };

  const [activeMenu, setActiveMenu] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [selectAll, setSelectAll] = useState(false);
  const [showPageSizeDropdown, setShowPageSizeDropdown] = useState(false);
  const [selectedPageSize, setSelectedPageSize] = useState(10);

  const pageSizeOptions = [10, 20, 50];

  const handleFilter = () => {
    router.push("/catalogue/product-search/filter");
  };

  const handleEditProduct = () => {
    router.push("/catalogue/product-search/edit-product");
  };

  const handleCheckboxChange = (id) => {
    setFilters(
      filters.map((filter) =>
        filter.id === id ? { ...filter, selected: !filter.selected } : filter
      )
    );
  };

  const handleSelectAll = () => {
    const newSelectAll = !selectAll;
    setSelectAll(newSelectAll);
    setFilters(
      filters.map((filter) => ({
        ...filter,
        selected: newSelectAll,
      }))
    );
  };

  const toggleMenu = (index) => {
    setActiveMenu(activeMenu === index ? null : index);
  };

  const handleMenuAction = (action, id) => {
    console.log(`${action} action for filter ${id}`);
    setActiveMenu(null);
  };

  const handlePageChange = (direction) => {
    if (direction === "next" && currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    } else if (direction === "prev" && currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const togglePageSizeDropdown = () => {
    setShowPageSizeDropdown(!showPageSizeDropdown);
  };

  const handlePageSizeSelect = (size) => {
    setSelectedPageSize(size);
    setItemsPerPage(size);
    setShowPageSizeDropdown(false);
    setCurrentPage(1); // Reset to first page when changing page size
  };

  // Calculate pagination
  const totalPages = Math.ceil(filters.length / itemsPerPage);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filters.slice(indexOfFirstItem, indexOfLastItem);

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h2 className={styles.title}>Product Search</h2>
        <div className={styles.searchContainer}>
          <div className={styles.inputWrapper}>
            <Search className={styles.searchIcon} />
            <input
              type="text"
              placeholder="Search Product"
              className={styles.searchInput}
            />
          </div>

          <button className={styles.addButton} onClick={handleFilter}>
            <MdTune />
            Filter
          </button>
        </div>
      </div>

      <div className={styles.tableContainer}>
        <table className={styles.filtersTable}>
          <thead>
            <tr>
              <th className={styles.checkboxColumn}>
                <input
                  type="checkbox"
                  onChange={handleSelectAll}
                  checked={selectAll}
                />
              </th>
              <th className={styles.idColumn}>ID</th>
              <th className={styles.nameColumn}>Product Name</th>
              <th className={styles.catalogueColumn}>Catalogue Name</th>
              <th className={styles.skuColumn}>SKU</th>
              <th className={styles.vendorColumn}>Vendor</th>
              <th className={styles.categoryColumn}>Category</th>
              <th className={styles.priceColumn}>Price</th>
              <th className={styles.stockColumn}>Stock</th>
              <th className={styles.statusColumn}>Status</th>
              <th className={styles.actionsColumn}></th>
            </tr>
          </thead>
          <tbody>
            {currentItems.map((filter, index) => (
              <tr
                key={filter.id}
                className={filter.selected ? styles.selectedRow : ""}
              >
                <td className={styles.checkboxColumn}>
                  <input
                    type="checkbox"
                    checked={filter.selected}
                    onChange={() => handleCheckboxChange(filter.id)}
                  />
                </td>
                <td className={styles.idColumn}>{filter.id}</td>
                <td className={styles.nameColumn}>
                  <div className={styles.productNameContainer}>
                    <span className={styles.productIcon}>{filter.icon}</span>
                    <span className={styles.productName}>
                      {filter.productName}
                    </span>
                  </div>
                </td>
                <td className={styles.catalogueColumn}>
                  {filter.catalogueName}
                </td>
                <td className={styles.skuColumn}>{filter.sku}</td>
                <td className={styles.vendorColumn}>{filter.vendor}</td>
                <td className={styles.categoryColumn}>{filter.category}</td>
                <td className={styles.priceColumn}>{filter.price}</td>
                <td className={styles.stockColumn}>{filter.stock}</td>
                <td className={styles.statusColumn}>
                  <span
                    className={`${styles.statusBadge} ${
                      statusColor[filter.status]
                    }`}
                  >
                    {filter.status}
                  </span>
                </td>
                <td className={styles.actionsColumn}>
                  <button
                    className={styles.menuButton}
                    onClick={() => toggleMenu(index)}
                  >
                    <span className={styles.menuDots}>⋮</span>
                  </button>
                  {activeMenu === index && (
                    <div className={styles.menuDropdown}>
                      <button onClick={handleEditProduct}>Edit</button>
                      <button
                        onClick={() => handleMenuAction("update", filter.id)}
                      >
                        Update
                      </button>
                      <button
                        onClick={() => handleMenuAction("delete", filter.id)}
                        className={styles.deleteButton}
                      >
                        Delete
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className={styles.tableContainer}>
        <div className={styles.pagination}>
          <div className={styles.paginationButtons}>
            <button className={styles.paginationButton}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polyline points="15 18 9 12 15 6" />
              </svg>
            </button>
            <button className={styles.paginationButton}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polyline points="9 18 15 12 9 6" />
              </svg>
            </button>
          </div>
          <div className={styles.paginationInfo}>
            <span>Show</span>
            <div className={styles.customDropdown}>
              <button
                className={styles.dropdownButton}
                onClick={togglePageSizeDropdown}
              >
                {selectedPageSize}
                <AiOutlineCaretDown
                  className={`${styles.dropdownIcon} ${
                    showPageSizeDropdown ? styles.rotated : ""
                  }`}
                />
              </button>

              {showPageSizeDropdown && (
                <div className={styles.dropdownMenu}>
                  {pageSizeOptions.map((option) => (
                    <div
                      key={option}
                      className={`${styles.dropdownItem} ${
                        selectedPageSize === option ? styles.selected : ""
                      }`}
                      onClick={() => handlePageSizeSelect(option)}
                    >
                      {option}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
