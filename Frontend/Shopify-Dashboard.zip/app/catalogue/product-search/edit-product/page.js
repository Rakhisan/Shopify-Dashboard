import EditProduct from "@/app/catalogue/product-search/edit-product/EditProduct";

export default function EditProductPage() {
  return <EditProduct />;
}
