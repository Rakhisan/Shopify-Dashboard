import ProductSearch from "@/app/catalogue/product-search/ProductSearch";

// import VendorSetup from "../../../components/catalogue/vendorsetup";

export default function ProductSearchPage() {
  return <ProductSearch />;
}
