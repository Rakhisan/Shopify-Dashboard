import Filter from "@/app/catalogue/product-search/filter/Filter";

export default function FilterPage() {
  return <Filter />;
}
