import CatalogueFilter from "@/app/catalogue/catalog-filter/CatalogueFilter";

export default function CatalogFilterPage() {
  return <CatalogueFilter />;
}
