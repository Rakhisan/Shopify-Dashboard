// components/CatalogueFilter.js

"use client";
import styles from "./CatalogueFilter.module.css";
import { Plus } from "lucide-react";
import { FaSearch } from "react-icons/fa";
import { useState } from "react";

export default function CatalogueFilter() {
  const [filters, setFilters] = useState([
    {
      id: "#301012",
      name: "Electronics In Stock",
      criteria: "Smart Devices & Innovation",
      createdBy: "Alex Johnson",
      productCount: "1900",
      selected: false,
    },
    {
      id: "#301011",
      name: "Home Appliances Available",
      criteria: "Tech/Next",
      createdBy: "Emily Davis",
      productCount: "1600",
      selected: false,
    },
    {
      id: "#301002",
      name: "Gadgets On Sale",
      criteria: "Tech/Next",
      createdBy: "Michael Brown",
      productCount: "1700",
      selected: false,
    },
    {
      id: "#301001",
      name: "Latest Smartphones",
      criteria: "Tech/Next",
      createdBy: "Sarah Wilson",
      productCount: "1800",
      selected: false,
    },
    {
      id: "#301000",
      name: "Laptops and Notebooks",
      criteria: "Tech/Next",
      createdBy: "David Lee",
      productCount: "1900",
      selected: false,
    },
    {
      id: "#301800",
      name: "Wearable Tech Items",
      criteria: "Tech/Next",
      createdBy: "Jessica Taylor",
      productCount: "2000",
      selected: false,
    },
    {
      id: "#301701",
      name: "Smart Home Devices",
      criteria: "Tech/Next",
      createdBy: "Daniel Martinez",
      productCount: "2100",
      selected: false,
    },
    {
      id: "#301600",
      name: "Gaming Consoles",
      criteria: "Tech/Next",
      createdBy: "Laura Anderson",
      productCount: "2200",
      selected: false,
    },
    {
      id: "#301500",
      name: "Audio Equipment",
      criteria: "Tech/Next",
      createdBy: "James Thomas",
      productCount: "2300",
      selected: false,
    },
    {
      id: "#301400",
      name: "Computer Accessories",
      criteria: "Tech/Next",
      createdBy: "Sophia White",
      productCount: "2400",
      selected: false,
    },
  ]);

  const [activeMenu, setActiveMenu] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const handleCheckboxChange = (id) => {
    setFilters(
      filters.map((filter) =>
        filter.id === id ? { ...filter, selected: !filter.selected } : filter
      )
    );
  };

  const toggleMenu = (id) => {
    if (activeMenu === id) {
      setActiveMenu(null);
    } else {
      setActiveMenu(id);
    }
  };

  const handleMenuAction = (action, id) => {
    console.log(`${action} action for filter ${id}`);
    setActiveMenu(null);
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  // Calculate pagination
  const totalPages = Math.ceil(filters.length / itemsPerPage);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filters.slice(indexOfFirstItem, indexOfLastItem);

  // Import font in the head section if using Next.js pages directory
  // const addPublicSansFont = () => {
  //   return (
  //     <style jsx global>{`
  //       @import url("https://fonts.googleapis.com/css2?family=Public+Sans:wght@300;400;500;600;700&display=swap");
  //     `}</style>
  //   );
  // };

  return (
    <div className={styles.container}>
      {/* <div className={styles.tableContainer}> */}
      {/* {addPublicSansFont()} */}
      <div className={styles.header}>
        <h2 className={styles.title}>Catalogue Filters</h2>
        <div className={styles.searchContainer}>
          <div className={styles.inputWrapper}>
            <FaSearch className={styles.searchIcon} />
            <input
              type="text"
              placeholder="Search Catalog"
              className={styles.searchInput}
            />
          </div>

          <button className={styles.addButton}>
            <Plus size={20} />
            Catalogue
          </button>

          <div className={styles.filterOptions}>
            <div className={styles.showOptions}>
              <span>Show</span>
              <select
                className={styles.showSelect}
                value={itemsPerPage}
                onChange={(e) => setItemsPerPage(Number(e.target.value))}
              >
                <option value={5}>5</option>
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={50}>50</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.tableContainer}>
        <table className={styles.filtersTable}>
          <thead>
            <tr>
              <th className={styles.checkboxColumn}>
                <input
                  type="checkbox"
                  onChange={() => {
                    const allSelected = filters.every(
                      (filter) => filter.selected
                    );
                    setFilters(
                      filters.map((filter) => ({
                        ...filter,
                        selected: !allSelected,
                      }))
                    );
                  }}
                  checked={
                    filters.length > 0 &&
                    filters.every((filter) => filter.selected)
                  }
                />
              </th>
              <th className={styles.idColumn}>ID</th>
              <th className={styles.nameColumn}>Filter Name</th>
              <th className={styles.criteriaColumn}>Criteria</th>
              <th className={styles.createdByColumn}>Created By</th>
              <th className={styles.countColumn}>Product Count</th>
              <th className={styles.actionsColumn}></th>
            </tr>
          </thead>
          <tbody>
            {currentItems.map((filter) => (
              <tr
                key={filter.id}
                className={filter.selected ? styles.selectedRow : ""}
              >
                <td className={styles.checkboxColumn}>
                  <input
                    type="checkbox"
                    checked={filter.selected}
                    onChange={() => handleCheckboxChange(filter.id)}
                  />
                </td>
                <td className={styles.idColumn}>{filter.id}</td>
                <td className={styles.nameColumn}>{filter.name}</td>
                <td className={styles.criteriaColumn}>{filter.criteria}</td>
                <td className={styles.createdByColumn}>{filter.createdBy}</td>
                <td className={styles.countColumn}>{filter.productCount}</td>
                <td className={styles.actionsColumn}>
                  <button
                    className={styles.menuButton}
                    onClick={() => toggleMenu(filter.id)}
                  >
                    <span className={styles.menuDots}>⋮</span>
                  </button>
                  {activeMenu === filter.id && (
                    <div className={styles.menuDropdown}>
                      <button
                        onClick={() => handleMenuAction("edit", filter.id)}
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleMenuAction("update", filter.id)}
                      >
                        Update
                      </button>
                      <button
                        onClick={() => handleMenuAction("delete", filter.id)}
                      >
                        Delete
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className={styles.pagination}>
          <div className={styles.paginationButtons}>
            <button className={styles.paginationButton}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polyline points="15 18 9 12 15 6" />
              </svg>
            </button>
            <button className={styles.paginationButton}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polyline points="9 18 15 12 9 6" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
