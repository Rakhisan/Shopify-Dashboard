"use client";

import { useState } from "react";
import Link from "next/link";
import styles from "../styles/Sidebar.module.css";
import { RxDashboard } from "react-icons/rx";
import { BsPerson } from "react-icons/bs";
import { SlSettings } from "react-icons/sl";
import { IoWalletOutline } from "react-icons/io5";
import { MdShowChart } from "react-icons/md";

export default function Sidebar() {
  const [expandedMenus, setExpandedMenus] = useState({
    admin: false,
    company: true,
    users: false,
    catalogue: false,
    export: false,
  });

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMenu = (menu) => {
    setExpandedMenus({
      ...expandedMenus,
      [menu]: !expandedMenus[menu],
    });
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        className={styles.mobileMenuButton}
        onClick={toggleMobileMenu}
        aria-label="Toggle menu"
      >
        <div
          className={`${styles.hamburger} ${
            isMobileMenuOpen ? styles.open : ""
          }`}
        >
          <span></span>
          <span></span>
          <span></span>
        </div>
      </button>

      {/* Mobile Overlay */}
      {isMobileMenuOpen && (
        <div className={styles.mobileOverlay} onClick={closeMobileMenu}></div>
      )}

      {/* Sidebar */}
      <div
        className={`${styles.sidebar} ${
          isMobileMenuOpen ? styles.mobileOpen : ""
        }`}
      >
        <nav className={styles.nav}>
          <ul>
            <li>
              <Link href="/dashboard" onClick={closeMobileMenu}>
                <div className={styles.navItem}>
                  <div className={styles.icon}>
                    <RxDashboard />
                  </div>
                  <span>Dashboard</span>
                </div>
              </Link>
            </li>
            <li>
              <div
                className={styles.navItem}
                onClick={() => toggleMenu("admin")}
              >
                <div className={styles.icon}>
                  <BsPerson />
                </div>
                <span>Admin</span>
                <div
                  className={`${styles.chevron} ${
                    expandedMenus.admin ? styles.expanded : ""
                  }`}
                >
                  <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path
                      fillRule="evenodd"
                      d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
              </div>

              {expandedMenus.admin && (
                <ul className={styles.submenu}>
                  <li>
                    <Link href="/admin/company" onClick={closeMobileMenu}>
                      <div
                        className={`${styles.navItem} ${styles.subItem} `}
                        onClick={() => toggleMenu("company")}
                      >
                        <span>Company</span>
                        <div
                          className={`${styles.chevron} ${
                            expandedMenus.company ? styles.expanded : ""
                          }`}
                        ></div>
                      </div>
                    </Link>
                  </li>

                  <li>
                    <Link href="/admin/user" onClick={closeMobileMenu}>
                      <div
                        className={`${styles.navItem} ${styles.subItem}`}
                        onClick={() => toggleMenu("users")}
                      >
                        <span>Users</span>
                        <div
                          className={`${styles.chevron} ${
                            expandedMenus.users ? styles.expanded : ""
                          }`}
                        ></div>
                      </div>
                    </Link>
                  </li>
                </ul>
              )}
            </li>
            <li>
              <div
                className={styles.navItem}
                onClick={() => toggleMenu("catalogue")}
              >
                <div className={styles.icon}>
                  <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10 9a3 3 0 100-6 3 3 0 000 6zM6 8a2 2 0 00-2 2v1a2 2 0 002 2h8a2 2 0 002-2v-1a2 2 0 00-2-2H6z" />
                  </svg>
                </div>
                <span>Catalogue</span>

                <div
                  className={`${styles.chevron} ${
                    expandedMenus.catalogue ? styles.expanded : ""
                  }`}
                >
                  <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path
                      fillRule="evenodd"
                      d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
              </div>

              {expandedMenus.catalogue && (
                <ul className={styles.submenu}>
                  <li>
                    <Link
                      href="/catalogue/vendor-setup"
                      onClick={closeMobileMenu}
                    >
                      <div
                        className={`${styles.navItem} ${styles.subItem} ${
                          expandedMenus.vendorsetup ? styles.active : ""
                        }`}
                        onClick={() => toggleMenu("vendor-setup")}
                      >
                        <span>Vendor Setup</span>
                        <div
                          className={`${styles.chevron} ${
                            expandedMenus.vendorsetup ? styles.expanded : ""
                          }`}
                        ></div>
                      </div>
                    </Link>
                  </li>

                  <li>
                    <Link
                      href="/catalogue/your-catalog"
                      onClick={closeMobileMenu}
                    >
                      <div
                        className={`${styles.navItem} ${styles.subItem}`}
                        onClick={() => toggleMenu("your-catalog")}
                      >
                        <span>Your Catalog</span>
                        <div
                          className={`${styles.chevron} ${
                            expandedMenus.yourcatalog ? styles.expanded : ""
                          }`}
                        ></div>
                      </div>
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/catalogue/catalog-filter"
                      onClick={closeMobileMenu}
                    >
                      <div
                        className={`${styles.navItem} ${styles.subItem}`}
                        onClick={() => toggleMenu("catalog-filter")}
                      >
                        <span>Catalog Filters</span>
                        <div
                          className={`${styles.chevron} ${
                            expandedMenus.catalogfilter ? styles.expanded : ""
                          }`}
                        ></div>
                      </div>
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/catalogue/product-search"
                      onClick={closeMobileMenu}
                    >
                      <div
                        className={`${styles.navItem} ${styles.subItem}`}
                        onClick={() => toggleMenu("product-search")}
                      >
                        <span>Product Search</span>
                        <div
                          className={`${styles.chevron} ${
                            expandedMenus.productsearch ? styles.expanded : ""
                          }`}
                        ></div>
                      </div>
                    </Link>
                  </li>
                </ul>
              )}
            </li>
            <li>
              <Link href="/price" onClick={closeMobileMenu}>
                <div className={styles.navItem}>
                  <div className={styles.icon}>
                    <IoWalletOutline />
                  </div>
                  <span>Price</span>
                </div>
              </Link>
            </li>

            <li>
              <div
                className={styles.navItem}
                onClick={() => toggleMenu("export")}
              >
                <div className={styles.icon}>
                  <MdShowChart />
                </div>
                <span>Export</span>
                <div
                  className={`${styles.chevron} ${
                    expandedMenus.export ? styles.expanded : ""
                  }`}
                >
                  <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path
                      fillRule="evenodd"
                      d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
              </div>

              {expandedMenus.export && (
                <ul className={styles.submenu}>
                  <li>
                    <Link
                      href="/export/export-dashboard"
                      onClick={closeMobileMenu}
                    >
                      <div
                        className={`${styles.navItem} ${styles.subItem} ${
                          expandedMenus.exportdashboard ? styles.active : ""
                        }`}
                        onClick={() => toggleMenu("export-dashboard")}
                      >
                        <span>Dashboard</span>
                        <div
                          className={`${styles.chevron} ${
                            expandedMenus.exportdashboard ? styles.expanded : ""
                          }`}
                        ></div>
                      </div>
                    </Link>
                  </li>

                  <li>
                    <Link
                      href="/export/export-to-channel"
                      onClick={closeMobileMenu}
                    >
                      <div
                        className={`${styles.navItem} ${styles.subItem}`}
                        onClick={() => toggleMenu("export-to-channel")}
                      >
                        <span>Export to Channels </span>
                        <div
                          className={`${styles.chevron} ${
                            expandedMenus.exporttochannel ? styles.expanded : ""
                          }`}
                        ></div>
                      </div>
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/export/import-from-channel"
                      onClick={closeMobileMenu}
                    >
                      <div
                        className={`${styles.navItem} ${styles.subItem}`}
                        onClick={() => toggleMenu("import-from-channel")}
                      >
                        <span>Import from Channel</span>
                        <div
                          className={`${styles.chevron} ${
                            expandedMenus.importfromchannel
                              ? styles.expanded
                              : ""
                          }`}
                        ></div>
                      </div>
                    </Link>
                  </li>
                </ul>
              )}
            </li>
            <li>
              <Link href="/setting" onClick={closeMobileMenu}>
                <div className={styles.navItem}>
                  <div className={styles.icon}>
                    <SlSettings />
                  </div>
                  <span>Settings</span>
                </div>
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </>
  );
}
