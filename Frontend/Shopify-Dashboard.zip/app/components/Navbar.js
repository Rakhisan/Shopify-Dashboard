// components/Navbar.js

"use client";
import { useState } from "react";
import styles from "../styles/Navbar.module.css";
import Image from "next/image";
import logo from "../images/logo.png";
import { FcManager } from "react-icons/fc";

export default function Navbar() {
  const [showSearch, setShowSearch] = useState(false);

  return (
    <div className={styles.navbar}>
      <div className={styles.leftSection}>
        <Image
          src={logo}
          alt="Shopify Logo"
          width={130}
          height={40}
          className={styles.logo}
        />
        <div className={styles.title}>Dashboard</div>
      </div>

      {/* Desktop Search - Always visible on desktop */}
      <div className={`${styles.searchContainer} ${styles.desktopSearch}`}>
        <div className={styles.searchIcon}>
          <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            <path
              fillRule="evenodd"
              d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
              clipRule="evenodd"
            />
          </svg>
        </div>
        <input
          type="text"
          className={styles.searchInput}
          placeholder="Search anything..."
        />
      </div>

      {/* Mobile Search - Toggleable */}
      {showSearch && (
        <div className={`${styles.searchContainer} ${styles.mobileSearch}`}>
          <div className={styles.searchIcon}>
            <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path
                fillRule="evenodd"
                d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                clipRule="evenodd"
              />
            </svg>
          </div>
          <input
            type="text"
            className={styles.searchInput}
            placeholder="Search..."
            autoFocus
          />
          <button
            className={styles.closeSearch}
            onClick={() => setShowSearch(false)}
          >
            ×
          </button>
        </div>
      )}

      <div className={styles.rightSection}>
        {/* Mobile Search Toggle Button */}
        {/* <button
          className={`${styles.iconButton} ${styles.mobileSearchToggle}`}
          onClick={() => setShowSearch(!showSearch)}
        >
          <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            <path
              fillRule="evenodd"
              d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
              clipRule="evenodd"
            />
          </svg>
        </button> */}

        <div className={`${styles.iconButton} ${styles.hideOnMobile}`}>
          <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            <path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z" />
          </svg>
        </div>

        <div className={`${styles.iconButton} ${styles.hideOnMobile}`}>
          <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            <path
              fillRule="evenodd"
              d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z"
              clipRule="evenodd"
            />
          </svg>
        </div>

        <div className={styles.profile}>
          <div className={styles.avatar}>
            <img src="/api/placeholder/32/32" alt="User avatar" />
          </div>
        </div>
      </div>
    </div>
  );
}
